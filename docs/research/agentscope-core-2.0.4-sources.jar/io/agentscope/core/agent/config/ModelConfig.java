/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.core.agent.config;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.agentscope.core.model.Model;

/**
 * Model invocation configuration. {@link #maxRetries()} bounds the retry count on a single
 * model call; {@link #fallbackModel()} (nullable) is invoked if the primary model still fails
 * after exhausting retries — the fallback shares the same {@code maxRetries} budget. {@link
 * #failoverListener()} (nullable) is notified when such a switch happens.
 *
 * <p>The {@code fallbackModel} and {@code failoverListener} fields are intentionally excluded
 * from JSON serialisation ({@code @JsonIgnore}): they hold live instances (credentials,
 * connections, callbacks) that don't round-trip cleanly through a state snapshot.
 */
public record ModelConfig(
        int maxRetries,
        @JsonIgnore Model fallbackModel,
        @JsonIgnore FailoverListener failoverListener) {

    public static final int DEFAULT_MAX_RETRIES = 3;

    public ModelConfig {
        if (maxRetries <= 0) {
            throw new IllegalArgumentException("maxRetries must be > 0: " + maxRetries);
        }
    }

    /**
     * Convenience constructor without failover observation; equivalent to passing a {@code null}
     * listener.
     */
    public ModelConfig(int maxRetries, Model fallbackModel) {
        this(maxRetries, fallbackModel, null);
    }

    /** Returns a config initialised to all default values (no fallback model). */
    public static ModelConfig defaults() {
        return new ModelConfig(DEFAULT_MAX_RETRIES, null, null);
    }
}
