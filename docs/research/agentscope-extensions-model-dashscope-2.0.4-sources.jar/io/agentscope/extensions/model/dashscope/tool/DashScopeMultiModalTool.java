/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.extensions.model.dashscope.tool;

import com.alibaba.dashscope.aigc.imagesynthesis.ImageSynthesis;
import com.alibaba.dashscope.aigc.imagesynthesis.ImageSynthesisOutput;
import com.alibaba.dashscope.aigc.imagesynthesis.ImageSynthesisParam;
import com.alibaba.dashscope.aigc.imagesynthesis.ImageSynthesisResult;
import com.alibaba.dashscope.aigc.multimodalconversation.MultiModalConversation;
import com.alibaba.dashscope.aigc.multimodalconversation.MultiModalConversationOutput;
import com.alibaba.dashscope.aigc.multimodalconversation.MultiModalConversationParam;
import com.alibaba.dashscope.aigc.multimodalconversation.MultiModalConversationResult;
import com.alibaba.dashscope.aigc.videosynthesis.VideoSynthesis;
import com.alibaba.dashscope.aigc.videosynthesis.VideoSynthesisOutput;
import com.alibaba.dashscope.aigc.videosynthesis.VideoSynthesisParam;
import com.alibaba.dashscope.aigc.videosynthesis.VideoSynthesisResult;
import com.alibaba.dashscope.audio.asr.recognition.Recognition;
import com.alibaba.dashscope.audio.asr.recognition.RecognitionParam;
import com.alibaba.dashscope.audio.asr.recognition.RecognitionResult;
import com.alibaba.dashscope.audio.tts.SpeechSynthesisAudioFormat;
import com.alibaba.dashscope.audio.tts.SpeechSynthesisParam;
import com.alibaba.dashscope.audio.tts.SpeechSynthesizer;
import com.alibaba.dashscope.common.MultiModalMessage;
import com.alibaba.dashscope.common.ResultCallback;
import com.alibaba.dashscope.common.Role;
import io.agentscope.core.Version;
import io.agentscope.core.formatter.MediaUtils;
import io.agentscope.core.message.AudioBlock;
import io.agentscope.core.message.Base64Source;
import io.agentscope.core.message.ContentBlock;
import io.agentscope.core.message.ImageBlock;
import io.agentscope.core.message.TextBlock;
import io.agentscope.core.message.ToolResultBlock;
import io.agentscope.core.message.URLSource;
import io.agentscope.core.message.VideoBlock;
import io.agentscope.core.tool.Tool;
import io.agentscope.core.tool.ToolParam;
import io.agentscope.core.util.JsonUtils;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

/**
 * DashScope multimodal tool.
 * <p>
 * Support tools:
 * <ul>
 *     <li>dashscope_text_to_image: Generate image(s) based on the given text.</li>
 *     <li>dashscope_image_to_image: Edit/transform an image based on a text prompt and the input image.</li>
 *     <li>dashscope_image_to_text: Generate text based on the given images.</li>
 *     <li>dashscope_text_to_audio: Convert the given text to audio.</li>
 *     <li>dashscope_audio_to_text: Convert the given audio to text.</li>
 *     <li>dashscope_text_to_video: Generate video based on the given text prompt.</li>
 *     <li>dashscope_image_to_video: Generate a video from a single input image and an optional text prompt.</li>
 *     <li>dashscope_first_and_last_frame_image_to_video: Generate video transitioning from a first frame to a last frame and an optional text prompt.</li>
 *     <li>dashscope_video_to_text: Analyze video and generate a text description or answer questions based on the video content.</li>
 * </ul>
 * convert text to images, convert images to text, convert text to audio, and convert audio to text.
 * Please refer to the <a href="https://dashscope.aliyun.com/">`dashscope documentation`</a> for more details.
 */
public class DashScopeMultiModalTool {

    private static final Logger log = LoggerFactory.getLogger(DashScopeMultiModalTool.class);

    /**
     * Default model of {@code dashscope_image_to_image}. It has to be an edit model: the pure
     * text-to-image models of the same family reject an {@code input.messages} payload carrying an
     * image.
     */
    private static final String DEFAULT_IMAGE_EDIT_MODEL = "qwen-image-edit";

    /**
     * Prefix of the qwen-image family. The first generation names its edit models with an
     * {@code -edit} token ({@code qwen-image-edit}, {@code -plus}, {@code -max}); every numbered
     * generation from 2.0 on drops that token and carries the generation instead
     * ({@code qwen-image-2.0}, {@code qwen-image-2.0-pro}). Both spellings edit an input image,
     * whereas the versionless {@code qwen-image} / {@code qwen-image-plus} are text-to-image only.
     */
    private static final String QWEN_IMAGE_PREFIX = "qwen-image-";

    /**
     * DashScope API key.
     */
    private final String apiKey;

    public DashScopeMultiModalTool(String apiKey) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("DashScope API key cannot be empty.");
        }
        this.apiKey = apiKey;
    }

    /**
     * Generate image(s) based on the given prompt, and return image url(s) or base64 data.
     *
     * @param prompt    The text prompt to generate image
     * @param model     The model to use, e.g., 'wanx-v1', 'qwen-image', 'wan2.2-t2i-flash', etc.
     * @param n         The number of images to generate
     * @param size      Size of the image, e.g., '1024*1024', '1280*1280', '800*1200', etc.
     * @param useBase64 Whether to use base64 data for images
     * @return A ToolResultBlock containing the generated image url, base64 data, or error message.
     */
    @Tool(
            name = "dashscope_text_to_image",
            description =
                    "Generate image(s) based on the given prompt, and return image url(s) or base64"
                            + " data.")
    public Mono<ToolResultBlock> dashscopeTextToImage(
            @ToolParam(name = "prompt", description = "The text prompt to generate image")
                    String prompt,
            @ToolParam(
                            name = "model",
                            description =
                                    "The model to use, e.g., 'wanx-v1', 'qwen-image',"
                                            + " 'wan2.2-t2i-flash', etc.",
                            required = false)
                    String model,
            @ToolParam(
                            name = "n",
                            description = "The number of images to generate",
                            required = false)
                    Integer n,
            @ToolParam(
                            name = "size",
                            description =
                                    "Size of the image, e.g., '1024*1024', '1280*1280', '800*1200',"
                                            + " etc.",
                            required = false)
                    String size,
            @ToolParam(
                            name = "use_base64",
                            description = "Whether to use base64 data for images",
                            required = false)
                    Boolean useBase64) {

        Integer finalN = Optional.ofNullable(n).orElse(1);
        String finalSize =
                Optional.ofNullable(size).filter(s -> !s.trim().isEmpty()).orElse("1024*1024");
        String finalModel =
                Optional.ofNullable(model).filter(s -> !s.trim().isEmpty()).orElse("wanx-v1");
        Boolean finalUseBase64 = Optional.ofNullable(useBase64).orElse(false);

        log.debug(
                "dashscope_text_to_image called: prompt='{}', n='{}', size='{}', model='{}',"
                        + " useBase64='{}'",
                prompt,
                finalN,
                finalSize,
                finalModel,
                useBase64);

        return Mono.fromCallable(
                        () -> {
                            ImageSynthesisParam param =
                                    ImageSynthesisParam.builder()
                                            .apiKey(this.apiKey)
                                            .prompt(prompt)
                                            .model(finalModel)
                                            .n(finalN)
                                            .size(finalSize)
                                            .header("user-agent", Version.getUserAgent())
                                            .build();
                            ImageSynthesis imageSynthesis = new ImageSynthesis();
                            ImageSynthesisResult response = imageSynthesis.call(param);

                            List<String> urls =
                                    Optional.ofNullable(response)
                                            .map(ImageSynthesisResult::getOutput)
                                            .map(ImageSynthesisOutput::getResults)
                                            .map(
                                                    results ->
                                                            results.stream()
                                                                    .map(item -> item.get("url"))
                                                                    .toList())
                                            .orElse(null);

                            if (urls == null || urls.isEmpty()) {
                                log.error("No image url returned.");
                                return ToolResultBlock.error("Failed to generate images.");
                            }

                            List<ContentBlock> contentBlocks = new ArrayList<>();
                            for (String url : urls) {
                                if (finalUseBase64) {
                                    String mediaType;
                                    String data;
                                    try {
                                        mediaType = MediaUtils.determineMediaType(url);
                                        data = MediaUtils.downloadUrlToBase64(url);
                                    } catch (IOException e) {
                                        log.error("Failed to generate images.");
                                        return ToolResultBlock.error(e.getMessage());
                                    }
                                    if (data == null || data.trim().isEmpty()) {
                                        log.error("Failed to convert image url to base64.");
                                        return ToolResultBlock.error("Failed to generate images.");
                                    }

                                    contentBlocks.add(
                                            ImageBlock.builder()
                                                    .source(
                                                            Base64Source.builder()
                                                                    .mediaType(mediaType)
                                                                    .data(data)
                                                                    .build())
                                                    .build());
                                } else {

                                    contentBlocks.add(
                                            ImageBlock.builder()
                                                    .source(URLSource.builder().url(url).build())
                                                    .build());
                                }
                            }
                            return ToolResultBlock.of(contentBlocks);
                        })
                .onErrorResume(
                        e -> {
                            log.error("Failed to generate images '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Edit or transform an image based on a text prompt and an input image.
     *
     * <p>Logging contract: only the kind and length of {@code image_url} and the length of
     * {@code prompt} are logged. Neither the reference itself nor the prompt text reaches the log,
     * because the reference may be a Base64 data URL carrying the whole image.
     *
     * @param imageUrl      The public URL, oss:// URL, local file path, or Base64 data URL of the
     *                      input image to edit.
     * @param prompt        The text prompt describing the desired edit or transformation.
     * @param model         The image-edit model to use, e.g., 'qwen-image-edit'.
     * @param size          Size of the output image, e.g., '1024*1024'. Supported by the numbered
     *                      generations (2.0 and later) and by the first-generation 'plus' and
     *                      'max' tiers.
     * @param useBase64     Whether to return image as base64 data instead of URL.
     * @return A ToolResultBlock containing the generated image url/base64 or error message.
     */
    @Tool(
            name = "dashscope_image_to_image",
            description =
                    "Edit or transform an existing image based on a text prompt and an input"
                            + " image. The input image must be reachable by the service: a public"
                            + " http(s) URL (the address an uploaded attachment is served from),"
                            + " an oss:// URL or a Base64 data URL. A path inside the sandbox"
                            + " workspace is not readable by this tool, so never invent one - ask"
                            + " for a link instead. Returns the edited image as URL or base64."
                            + " Use dashscope_text_to_image when there is no input image.")
    public Mono<ToolResultBlock> dashscopeImageToImage(
            @ToolParam(
                            name = "image_url",
                            description =
                                    "The URL, local file path or Base64 data URL (the format"
                                            + " pattern is data:[MIME_type];base64,{base64_image},"
                                            + " e.g., 'data:image/png;base64,iVBORw0KGgo...') of"
                                            + " the input image to edit")
                    String imageUrl,
            @ToolParam(
                            name = "prompt",
                            description =
                                    "The text prompt describing the desired edit or"
                                            + " transformation")
                    String prompt,
            @ToolParam(
                            name = "model",
                            description =
                                    "The image-edit model to use, e.g., 'qwen-image-edit',"
                                            + " 'qwen-image-edit-plus', 'qwen-image-edit-max',"
                                            + " 'qwen-image-2.0-pro'. Every numbered generation"
                                            + " (2.0 and later) edits an input image too."
                                            + " Text-to-image models such as 'qwen-image' or"
                                            + " 'wanx-v1' take no image input.",
                            required = false)
                    String model,
            @ToolParam(
                            name = "size",
                            description =
                                    "Size of the output image, e.g., '1024*1024', '1280*1280'."
                                            + " Only supported by 'qwen-image-edit-plus',"
                                            + " 'qwen-image-edit-max' and the numbered generations"
                                            + " ('qwen-image-2.0' and later); otherwise the"
                                            + " resolution follows the input image.",
                            required = false)
                    String size,
            @ToolParam(
                            name = "use_base64",
                            description = "Whether to return image as base64 data instead of URL",
                            required = false)
                    Boolean useBase64) {

        String finalModel =
                Optional.ofNullable(model)
                        .filter(s -> !s.trim().isEmpty())
                        .orElse(DEFAULT_IMAGE_EDIT_MODEL);
        Boolean finalUseBase64 = Optional.ofNullable(useBase64).orElse(false);

        // Rejected before the request is built, so an unusable model costs no call. This also has
        // to come first: resolving the size of a request that is about to be refused logs a
        // warning about a parameter that is never sent.
        if (rejectsImageInput(finalModel)) {
            log.error(
                    "dashscope_image_to_image rejected model '{}': it takes no image input on this"
                            + " endpoint",
                    finalModel);
            return Mono.just(ToolResultBlock.error(unsupportedEditModelMessage(finalModel)));
        }

        String finalSize = resolveOutputSize(finalModel, size);

        log.debug(
                "dashscope_image_to_image called: {}, model='{}', size='{}', useBase64='{}'",
                describeEditRequest(imageUrl, prompt),
                finalModel,
                finalSize,
                useBase64);

        return Mono.fromCallable(
                        () -> {
                            // This endpoint takes exactly one message and its role must be `user`.
                            // A leading system message, or any second message, is rejected with
                            // "Input should be 'user'" / "messages parameter length invalid".
                            List<Map<String, Object>> content = new ArrayList<>();
                            content.add(Map.of("image", toEditableImageRef(imageUrl)));
                            content.add(Map.of("text", prompt));

                            MultiModalMessage userMessage =
                                    MultiModalMessage.builder()
                                            .role(Role.USER.getValue())
                                            .content(content)
                                            .build();
                            List<MultiModalMessage> messages = List.of(userMessage);

                            var builder =
                                    MultiModalConversationParam.builder()
                                            .apiKey(this.apiKey)
                                            .model(finalModel)
                                            .messages(messages)
                                            .header("user-agent", Version.getUserAgent());
                            // An unsupported or empty `size` fails the whole request, so the entry
                            // is only added when the model accepts an explicit resolution.
                            if (finalSize != null) {
                                builder.parameter("size", finalSize);
                            }
                            MultiModalConversationParam param = builder.build();

                            MultiModalConversation conv = new MultiModalConversation();
                            MultiModalConversationResult result = conv.call(param);

                            // Extract image URL from response
                            String resultImageUrl =
                                    Optional.ofNullable(result)
                                            .map(MultiModalConversationResult::getOutput)
                                            .map(MultiModalConversationOutput::getChoices)
                                            .flatMap(choices -> choices.stream().findFirst())
                                            .map(MultiModalConversationOutput.Choice::getMessage)
                                            .map(MultiModalMessage::getContent)
                                            .flatMap(contents -> contents.stream().findFirst())
                                            .map(m -> m.get("image"))
                                            .map(Object::toString)
                                            .orElse(null);

                            if (resultImageUrl == null || resultImageUrl.isEmpty()) {
                                // Fallback: check if text response (error message from model)
                                String errorText =
                                        Optional.ofNullable(result)
                                                .map(MultiModalConversationResult::getOutput)
                                                .map(MultiModalConversationOutput::getChoices)
                                                .flatMap(c -> c.stream().findFirst())
                                                .map(
                                                        MultiModalConversationOutput.Choice
                                                                ::getMessage)
                                                .map(MultiModalMessage::getContent)
                                                .flatMap(c -> c.stream().findFirst())
                                                .map(m -> m.get("text"))
                                                .map(Object::toString)
                                                .orElse(null);
                                log.error(
                                        "No image URL returned from image-to-image."
                                                + " Response text: {}",
                                        errorText);
                                return ToolResultBlock.error(
                                        "Failed to generate image: "
                                                + (errorText != null
                                                        ? errorText
                                                        : "no image in response"));
                            }

                            List<ContentBlock> contentBlocks = new ArrayList<>();
                            if (finalUseBase64) {
                                String mediaType;
                                String data;
                                try {
                                    mediaType = MediaUtils.determineMediaType(resultImageUrl);
                                    data = MediaUtils.downloadUrlToBase64(resultImageUrl);
                                } catch (IOException e) {
                                    log.error("Failed to download generated image.");
                                    return ToolResultBlock.error(e.getMessage());
                                }
                                if (data == null || data.trim().isEmpty()) {
                                    return ToolResultBlock.error(
                                            "Failed to convert image to base64.");
                                }
                                contentBlocks.add(
                                        ImageBlock.builder()
                                                .source(
                                                        Base64Source.builder()
                                                                .mediaType(mediaType)
                                                                .data(data)
                                                                .build())
                                                .build());
                            } else {
                                contentBlocks.add(
                                        ImageBlock.builder()
                                                .source(
                                                        URLSource.builder()
                                                                .url(resultImageUrl)
                                                                .build())
                                                .build());
                            }
                            return ToolResultBlock.of(contentBlocks);
                        })
                .onErrorResume(
                        e -> {
                            log.error(
                                    "Failed to generate image from image '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Resolve the {@code size} parameter of an edit request. The base {@code qwen-image-edit} model
     * has no configurable output resolution and rejects the parameter, so it is dropped with a
     * warning instead of failing the whole call.
     */
    private static String resolveOutputSize(String model, String size) {
        String requested = Optional.ofNullable(size).filter(s -> !s.trim().isEmpty()).orElse(null);
        if (requested == null) {
            return null;
        }
        if (!supportsOutputSize(model)) {
            log.warn(
                    "dashscope_image_to_image drops size='{}' for model '{}': the output"
                            + " resolution follows the input image",
                    requested,
                    model);
            return null;
        }
        return requested;
    }

    /** Whether the model accepts an explicit output resolution. */
    private static boolean supportsOutputSize(String model) {
        String name = model.toLowerCase();
        // Sending a resolution the model does not accept fails the whole request, so the
        // first-generation names stay on an explicit list. Numbered generations are covered by
        // pattern: 2.0 accepts a resolution and there is no evidence a later one drops it.
        return isNumberedEditGeneration(name)
                || name.startsWith("qwen-image-edit-plus")
                || name.startsWith("qwen-image-edit-max");
    }

    /**
     * Whether the model belongs to a numbered generation of the image family, e.g.
     * {@code qwen-image-2.0}, {@code qwen-image-3.0-pro}. Matching the leading digit rather than a
     * concrete version keeps a model that has not been released yet working.
     */
    private static boolean isNumberedEditGeneration(String name) {
        return name.length() > QWEN_IMAGE_PREFIX.length()
                && name.startsWith(QWEN_IMAGE_PREFIX)
                && Character.isDigit(name.charAt(QWEN_IMAGE_PREFIX.length()));
    }

    /**
     * Whether the model cannot consume an input image on this endpoint: the wan family, whose image
     * editing runs on a different asynchronous task API, and the text-to-image members of the
     * qwen-image family.
     *
     * <p>Anything unrecognized is passed through to the service, which reports the real reason. A
     * false rejection here would silently remove a capability and attribute it to a cause the
     * message states incorrectly.
     */
    private static boolean rejectsImageInput(String model) {
        String name = model.toLowerCase();
        if (name.startsWith("wan")) {
            return true;
        }
        return name.startsWith("qwen-image")
                && !name.contains("edit")
                && !isNumberedEditGeneration(name);
    }

    /**
     * Summarize an edit request for logging without carrying any user payload.
     *
     * <p>{@code image_url} is allowed to be a Base64 data URL, so a single call can hand over the
     * entire encoded image. Writing it to an INFO/DEBUG line puts those bytes in the application
     * log - typically megabytes per line, and in the clear for anything that collects logs - and
     * the prompt is user content with no better claim to being logged. Both are therefore reduced
     * to a kind and a length here; not even a prefix of either value is rendered.
     */
    private static String describeEditRequest(String imageUrl, String prompt) {
        String ref = imageUrl == null ? "" : imageUrl.trim().toLowerCase();
        String kind;
        if (ref.isEmpty()) {
            kind = "absent";
        } else if (ref.startsWith("data:")) {
            kind = "base64-data-url";
        } else if (ref.startsWith("oss://")) {
            kind = "oss-url";
        } else if (ref.startsWith("http://") || ref.startsWith("https://")) {
            kind = "http-url";
        } else {
            kind = "local-path";
        }
        return "imageRef="
                + kind
                + "(len="
                + ref.length()
                + "), promptLength="
                + (prompt == null ? 0 : prompt.length());
    }

    /** Actionable hint returned instead of an opaque service-side parameter error. */
    private static String unsupportedEditModelMessage(String model) {
        return "Model '"
                + model
                + "' cannot edit an input image with this tool. Omit the model to"
                + " use '"
                + DEFAULT_IMAGE_EDIT_MODEL
                + "', or pass an edit model:"
                + " 'qwen-image-edit-plus', 'qwen-image-edit-max', 'qwen-image-2.0-pro'."
                + " dashscope_text_to_image is the right tool when there is no input image.";
    }

    /**
     * Normalize the input image reference. The documented formats are a public http(s) URL, an
     * {@code oss://} URL returned by the upload API, or a Base64 data URL; an existing local file
     * is inlined as Base64 rather than sent as a {@code file://} URL, which the endpoint rejects.
     */
    private static String toEditableImageRef(String imageUrl) throws IOException {
        if (MediaUtils.isFileExists(imageUrl)) {
            return MediaUtils.urlToBase64DataUrl(imageUrl);
        }
        return imageUrl;
    }

    /**
     * Generate text based on the given images.
     *
     * @param imageUrls The URL(s) of image(s) to be converted into text.
     * @param prompt    The text prompt.
     * @param model     The model to use, e.g., 'qwen3-vl-plus', qwen-vl-plus' 'qvq-plus', etc.
     * @return A ToolResultBlock containing the generated text or error message.
     */
    @Tool(
            name = "dashscope_image_to_text",
            description = "Generate text based on the given images.")
    public Mono<ToolResultBlock> dashscopeImageToText(
            @ToolParam(
                            name = "image_urls",
                            description =
                                    "The URL(s), local file path(s) or Base64 data URL(s)(the"
                                        + " format pattern is"
                                        + " data:[MIME_type];base64,{base64_image}, e.g.,"
                                        + " 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABDg...')"
                                        + " of image(s) to be converted into text.")
                    List<String> imageUrls,
            @ToolParam(name = "prompt", description = "The text prompt.", required = false)
                    String prompt,
            @ToolParam(
                            name = "model",
                            description =
                                    "The model to use, e.g., 'qwen3-vl-plus', qwen-vl-plus'"
                                            + " 'qwen-vl-max', etc.",
                            required = false)
                    String model) {

        String finalPrompt = Optional.ofNullable(prompt).orElse("Describe the image");
        String finalModel =
                Optional.ofNullable(model).filter(s -> !s.trim().isEmpty()).orElse("qwen3-vl-plus");
        log.debug("dashscope_image_to_text called: prompt='{}', model='{}'", prompt, finalModel);

        return Mono.fromCallable(
                        () -> {
                            List<MultiModalMessage> multiModalMessages = new ArrayList<>();
                            MultiModalMessage systemMessage =
                                    MultiModalMessage.builder()
                                            .role(Role.SYSTEM.getValue())
                                            .content(
                                                    List.of(
                                                            Map.of(
                                                                    "text",
                                                                    "You are a helpful"
                                                                            + " assistant.")))
                                            .build();

                            List<Map<String, Object>> content = new ArrayList<>();

                            for (String url : imageUrls) {
                                try {
                                    content.add(Map.of("image", MediaUtils.urlToProtocolUrl(url)));
                                } catch (IOException e) {
                                    return ToolResultBlock.error(e.getMessage());
                                }
                            }

                            content.add(Map.of("text", finalPrompt));
                            MultiModalMessage userMessage =
                                    MultiModalMessage.builder()
                                            .role(Role.USER.getValue())
                                            .content(content)
                                            .build();

                            multiModalMessages.add(systemMessage);
                            multiModalMessages.add(userMessage);

                            MultiModalConversationParam param =
                                    MultiModalConversationParam.builder()
                                            .apiKey(this.apiKey)
                                            .model(finalModel)
                                            .messages(multiModalMessages)
                                            .header("user-agent", Version.getUserAgent())
                                            .build();

                            MultiModalConversation conv = new MultiModalConversation();
                            MultiModalConversationResult result = conv.call(param);

                            String text =
                                    Optional.ofNullable(result)
                                            .map(MultiModalConversationResult::getOutput)
                                            .map(MultiModalConversationOutput::getChoices)
                                            .flatMap(choices -> choices.stream().findFirst())
                                            .map(MultiModalConversationOutput.Choice::getMessage)
                                            .map(MultiModalMessage::getContent)
                                            .flatMap(contents -> contents.stream().findFirst())
                                            .map(contentMap -> contentMap.get("text"))
                                            .map(Object::toString)
                                            .orElse(null);

                            if (text == null) {
                                log.error("MultiModalConversation response text is empty.");
                                return ToolResultBlock.error("Failed to generate text.");
                            }

                            return ToolResultBlock.of(TextBlock.builder().text(text).build());
                        })
                .onErrorResume(
                        e -> {
                            log.error("Failed to generate text '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Convert the given text to audio.
     *
     * <p>Supports two types of TTS models:
     * <ul>
     *   <li>Qwen TTS models (qwen3-tts-flash, qwen-tts) - uses multimodal-generation API</li>
     *   <li>Sambert models (sambert-*) - uses speech synthesis SDK</li>
     * </ul>
     *
     * @param text       The text to be converted into audio.
     * @param model      The TTS model to use. For Qwen TTS: 'qwen3-tts-flash', 'qwen-tts'.
     *                   For Sambert: 'sambert-zhinan-v1', 'sambert-zhiqi-v1', 'sambert-zhichu-v1', etc.
     * @param voice      Voice name for Qwen TTS models, e.g., 'Cherry', 'Serena'. Ignored for Sambert models.
     * @param language   Language type for Qwen TTS, e.g., 'Chinese', 'English'. Ignored for Sambert models.
     * @param sampleRate Sample rate of the audio (e.g., 16000, 24000, 48000).
     * @return A ToolResultBlock containing the base64 data of audio or error message.
     */
    @Tool(name = "dashscope_text_to_audio", description = "Convert the given text to audio.")
    public Mono<ToolResultBlock> dashscopeTextToAudio(
            @ToolParam(name = "text", description = "The text to be converted into audio.")
                    String text,
            @ToolParam(
                            name = "model",
                            description =
                                    "The TTS model to use. For Qwen TTS: 'qwen3-tts-flash',"
                                            + " 'qwen-tts'. For Sambert: 'sambert-zhinan-v1',"
                                            + " 'sambert-zhiqi-v1', 'sambert-zhichu-v1', etc.",
                            required = false)
                    String model,
            @ToolParam(
                            name = "voice",
                            description =
                                    "Voice name for Qwen TTS models, e.g., 'Cherry', 'Serena'."
                                            + " Ignored for Sambert models.",
                            required = false)
                    String voice,
            @ToolParam(
                            name = "language",
                            description =
                                    "Language type for Qwen TTS, e.g., 'Chinese', 'English'."
                                            + " Ignored for Sambert models.",
                            required = false)
                    String language,
            @ToolParam(
                            name = "sample_rate",
                            description = "Sample rate of the audio (e.g., 16000, 24000, 48000).",
                            required = false)
                    Integer sampleRate) {

        String finalModel =
                Optional.ofNullable(model)
                        .filter(s -> !s.trim().isEmpty())
                        .orElse("qwen3-tts-flash");
        Integer finalSampleRate = Optional.ofNullable(sampleRate).orElse(24000);

        // Check if it's a Qwen TTS model
        boolean isQwenTTS = finalModel.startsWith("qwen3-tts") || finalModel.startsWith("qwen-tts");

        log.debug(
                "dashscope_text_to_audio called: text='{}', model='{}', voice='{}', language='{}',"
                        + " sampleRate='{}', isQwenTTS='{}'",
                text,
                finalModel,
                voice,
                language,
                finalSampleRate,
                isQwenTTS);

        if (isQwenTTS) {
            return synthesizeWithQwenTTS(text, finalModel, voice, language);
        } else {
            return synthesizeWithSambert(text, finalModel, finalSampleRate);
        }
    }

    /**
     * Synthesizes audio using Qwen TTS models via the multimodal-generation API.
     *
     * <p>This method handles the HTTP communication with DashScope's Qwen TTS endpoint,
     * building the request payload with text, voice, and language parameters, then
     * parsing the response to extract audio data.
     *
     * <p>The method uses the multimodal-generation API endpoint which differs from
     * the standard speech synthesis endpoint used by other models.
     *
     * @param text the text to synthesize into speech
     * @param model the Qwen TTS model name (e.g., "qwen3-tts-flash", "qwen-tts")
     * @param voice the voice name for synthesis, defaults to "Cherry" if null/empty
     * @param language the language type, defaults to "Chinese" if null/empty
     * @return a Mono containing ToolResultBlock with AudioBlock on success,
     *         or an error ToolResultBlock on failure
     */
    private Mono<ToolResultBlock> synthesizeWithQwenTTS(
            String text, String model, String voice, String language) {
        String finalVoice =
                Optional.ofNullable(voice).filter(s -> !s.trim().isEmpty()).orElse("Cherry");
        String finalLanguage =
                Optional.ofNullable(language).filter(s -> !s.trim().isEmpty()).orElse("Chinese");

        return Mono.fromCallable(
                        () -> {
                            // Build request for Qwen TTS API
                            Map<String, Object> input = new HashMap<>();
                            input.put("text", text);
                            input.put("voice", finalVoice);
                            input.put("language_type", finalLanguage);

                            Map<String, Object> request = new HashMap<>();
                            request.put("model", model);
                            request.put("input", input);

                            String requestBody = JsonUtils.getJsonCodec().toJson(request);

                            // Call DashScope API using Java HttpClient
                            HttpClient client = HttpClient.newHttpClient();
                            HttpRequest httpRequest =
                                    HttpRequest.newBuilder()
                                            .uri(
                                                    URI.create(
                                                            "https://dashscope.aliyuncs.com/api/v1/services"
                                                                + "/aigc/multimodal-generation/generation"))
                                            .header("Authorization", "Bearer " + this.apiKey)
                                            .header("Content-Type", "application/json")
                                            .header("User-Agent", Version.getUserAgent())
                                            .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                                            .build();

                            HttpResponse<String> response =
                                    client.send(httpRequest, HttpResponse.BodyHandlers.ofString());

                            if (response.statusCode() != 200) {
                                log.error(
                                        "Qwen TTS API failed: status={}, body={}",
                                        response.statusCode(),
                                        response.body());
                                return ToolResultBlock.error(
                                        "TTS API failed: " + response.statusCode());
                            }

                            return parseQwenTTSResponse(response.body());
                        })
                .onErrorResume(
                        e -> {
                            log.error(
                                    "Failed to generate audio with Qwen TTS: '{}'",
                                    e.getMessage(),
                                    e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Parses the Qwen TTS API response and extracts audio data.
     *
     * <p>The response structure from Qwen TTS API is:
     * <pre>{@code
     * {
     *   "request_id": "...",
     *   "output": {
     *     "audio": {
     *       "url": "https://..."  // or "data": "base64..."
     *     }
     *   }
     * }
     * }</pre>
     *
     * <p>The method handles two audio formats:
     * <ul>
     *   <li>URL-based: returns AudioBlock with URLSource</li>
     *   <li>Base64-encoded: returns AudioBlock with Base64Source</li>
     * </ul>
     *
     * @param responseBody the raw JSON response body from the API
     * @return ToolResultBlock containing AudioBlock on success,
     *         or an error ToolResultBlock if parsing fails or response contains an error
     */
    private ToolResultBlock parseQwenTTSResponse(String responseBody) {
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> response =
                    JsonUtils.getJsonCodec().fromJson(responseBody, Map.class);

            // Check for error
            if (response.containsKey("code") && response.get("code") != null) {
                String message =
                        response.containsKey("message")
                                ? response.get("message").toString()
                                : "Unknown error";
                log.error("Qwen TTS error: {}", message);
                return ToolResultBlock.error(message);
            }

            // Extract audio from output
            @SuppressWarnings("unchecked")
            Map<String, Object> output = (Map<String, Object>) response.get("output");
            if (output == null) {
                return ToolResultBlock.error("No output in response");
            }

            @SuppressWarnings("unchecked")
            Map<String, Object> audio = (Map<String, Object>) output.get("audio");
            if (audio == null) {
                return ToolResultBlock.error("No audio in response");
            }

            // Check for URL or base64 data
            if (audio.containsKey("url") && audio.get("url") != null) {
                String url = audio.get("url").toString();
                return ToolResultBlock.of(
                        AudioBlock.builder().source(URLSource.builder().url(url).build()).build());
            } else if (audio.containsKey("data") && audio.get("data") != null) {
                String data = audio.get("data").toString();
                return ToolResultBlock.of(
                        AudioBlock.builder()
                                .source(
                                        Base64Source.builder()
                                                .mediaType("audio/wav")
                                                .data(data)
                                                .build())
                                .build());
            } else {
                return ToolResultBlock.error("No audio data in response");
            }
        } catch (Exception e) {
            log.error("Failed to parse Qwen TTS response: {}", e.getMessage());
            return ToolResultBlock.error("Failed to parse response: " + e.getMessage());
        }
    }

    /**
     * Synthesize audio using Sambert models via speech synthesis SDK.
     */
    private Mono<ToolResultBlock> synthesizeWithSambert(
            String text, String model, Integer sampleRate) {
        return Mono.fromCallable(
                        () -> {
                            SpeechSynthesisParam param =
                                    SpeechSynthesisParam.builder()
                                            .apiKey(this.apiKey)
                                            .text(text)
                                            .model(model)
                                            .sampleRate(sampleRate)
                                            .format(SpeechSynthesisAudioFormat.WAV)
                                            .header("user-agent", Version.getUserAgent())
                                            .build();
                            SpeechSynthesizer synthesizer = new SpeechSynthesizer();
                            ByteBuffer byteBuffer = synthesizer.call(param);
                            if (byteBuffer == null || byteBuffer.remaining() == 0) {
                                log.error("Audio byte buffer is empty.");
                                return ToolResultBlock.error("Failed to generate audio.");
                            }
                            byte[] bytes = new byte[byteBuffer.remaining()];
                            byteBuffer.get(bytes);
                            String data = Base64.getEncoder().encodeToString(bytes);

                            return ToolResultBlock.of(
                                    AudioBlock.builder()
                                            .source(
                                                    Base64Source.builder()
                                                            .mediaType("audio/wav")
                                                            .data(data)
                                                            .build())
                                            .build());
                        })
                .onErrorResume(
                        e -> {
                            log.error(
                                    "Failed to generate audio with Sambert: '{}'",
                                    e.getMessage(),
                                    e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Convert the given audio to text.
     *
     * @param audioUrl   The file path or URL of audio to be converted into text.
     * @param model      The speech recognition model to use, e.g., 'paraformer-realtime-v1', 'paraformer-realtime-8k-v1',
     *                  'paraformer-realtime-v2', 'paraformer-realtime-8k-v2'.
     * @param sampleRate Sample rate of the audio (e.g., 8000, 16000).
     * @return A ToolResultBlock containing the recognition text or error message.
     */
    @Tool(name = "dashscope_audio_to_text", description = "Convert the given audio to text.")
    public Mono<ToolResultBlock> dashscopeAudioToText(
            @ToolParam(
                            name = "audio_url",
                            description =
                                    "The file path or URL of audio to be converted into text.")
                    String audioUrl,
            @ToolParam(
                            name = "model",
                            description =
                                    "The TTS model to use, e.g., 'paraformer-realtime-v1',"
                                        + " 'paraformer-realtime-8k-v1', 'paraformer-realtime-v2',"
                                        + " 'paraformer-realtime-8k-v2'.",
                            required = false)
                    String model,
            @ToolParam(
                            name = "sample_rate",
                            description = "Sample rate of the audio (e.g., 8000, 16000).",
                            required = false)
                    Integer sampleRate) {

        String finalModel =
                Optional.ofNullable(model)
                        .filter(s -> !s.trim().isEmpty())
                        .orElse("paraformer-realtime-v2");
        Integer finalSampleRate = Optional.ofNullable(sampleRate).orElse(16000);
        log.debug(
                "dashscope_audio_to_text called: audioUrl='{}', model='{}', sampleRate='{}'",
                audioUrl,
                finalModel,
                finalSampleRate);

        return Mono.fromCallable(
                        () -> {
                            AtomicReference<TextBlock> textBlockRef = new AtomicReference<>(null);
                            CountDownLatch stopLatch = new CountDownLatch(1);

                            RecognitionParam param =
                                    RecognitionParam.builder()
                                            .apiKey(this.apiKey)
                                            .model(finalModel)
                                            .format(MediaUtils.getExtension(audioUrl))
                                            .sampleRate(finalSampleRate)
                                            // "language_hints" only support for
                                            // paraformer-realtime-v2 model
                                            .parameter("language_hints", new String[] {"zh", "en"})
                                            .header("user-agent", Version.getUserAgent())
                                            .build();
                            Recognition recognizer = new Recognition();
                            ResultCallback<RecognitionResult> callback =
                                    new ResultCallback<>() {
                                        @Override
                                        public void onEvent(RecognitionResult message) {
                                            String text = message.getSentence().getText();
                                            if (message.isSentenceEnd()) {
                                                log.debug("Final Result: " + text);
                                                textBlockRef.set(
                                                        TextBlock.builder().text(text).build());
                                            } else {
                                                log.debug("Intermediate Result: " + text);
                                            }
                                        }

                                        @Override
                                        public void onComplete() {
                                            stopLatch.countDown();
                                            log.debug("Recognition complete");
                                        }

                                        @Override
                                        public void onError(Exception e) {
                                            stopLatch.countDown();
                                            log.error(
                                                    "RecognitionCallback error: " + e.getMessage());
                                        }
                                    };

                            try {
                                recognizer.call(param, callback);

                                this.sendAudioChunk(audioUrl, recognizer);

                                recognizer.stop();

                                if (!stopLatch.await(60, TimeUnit.SECONDS)) {
                                    log.error("Timeout waiting for recognition to complete.");
                                    return ToolResultBlock.error("Failed to transcribe audio.");
                                }

                                TextBlock textBlock = textBlockRef.get();
                                if (textBlock == null) {
                                    log.error("Generate text is empty.");
                                    return ToolResultBlock.error("Failed to transcribe audio.");
                                }
                                return ToolResultBlock.of(textBlock);
                            } finally {
                                // Close Websocket until task is finished
                                log.debug("Finish transcribe audio.");
                                recognizer.getDuplexApi().close(1000, "bye");
                            }
                        })
                .onErrorResume(
                        e -> {
                            log.error("Failed to transcribe audio, '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Send audio input stream by chunk to DashScope.
     * marked as package-private for unit test.
     *
     * @param audioUrl   The file path or URL of audio.
     * @param recognizer DashScope Recognition instance
     * @throws IOException          if read failed
     * @throws InterruptedException if interrupted
     */
    void sendAudioChunk(String audioUrl, Recognition recognizer)
            throws IOException, InterruptedException {
        // chunk size set to 1 seconds for 16KHz sample rate
        byte[] buffer = new byte[3200];
        int bytesRead;
        if (MediaUtils.isFileExists(audioUrl)) {
            try ( // Read file and send audio by chunks
            InputStream is = Files.newInputStream(Paths.get(audioUrl))) {
                while ((bytesRead = is.read(buffer)) != -1) {
                    ByteBuffer byteBuffer = ByteBuffer.wrap(buffer, 0, bytesRead);
                    recognizer.sendAudioFrame(byteBuffer);

                    // Prevent high CPU usage
                    Thread.sleep(100);
                }
            }
        } else {
            try ( // Read web url and send audio by chunks
            InputStream is = URI.create(audioUrl).toURL().openStream()) {
                while ((bytesRead = is.read(buffer)) != -1) {
                    ByteBuffer byteBuffer = ByteBuffer.wrap(buffer, 0, bytesRead);
                    recognizer.sendAudioFrame(byteBuffer);

                    // Prevent high CPU usage
                    Thread.sleep(100);
                }
            }
        }
    }

    /**
     * Generate video based on the given prompt.
     *
     * @param prompt          The text prompt to generate video.
     * @param model           The model to use, e.g., 'wan2.6-t2v', 'wan2.5-t2v-preview', etc.
     * @param negativePrompt  The negative prompt to avoid certain elements.
     * @param audioUrl        The URL for background audio.
     * @param size            Size of the video, e.g., '1920*1080', '1280*720', etc.
     * @param duration        Duration of the video in seconds, e.g., '5', '10', etc.
     * @param shotType        Specify the shot type that generates the video.
     *                        single: default value, output single shot video; multi: output multi-lens video.
     * @param promptExtend    Whether to extend the prompt automatically (default true)
     * @param watermark       Whether to include watermark (default false)
     * @param seed            The seed for reproducibility
     * @return A ToolResultBlock containing the generated video url or error message.
     */
    @Tool(
            name = "dashscope_text_to_video",
            description = "Generate video based on the given text prompt")
    public Mono<ToolResultBlock> dashscopeTextToVideo(
            @ToolParam(name = "prompt", description = "The text prompt to generate video")
                    String prompt,
            @ToolParam(
                            name = "model",
                            description =
                                    "The model to use, e.g., 'wan2.6-t2v', 'wan2.5-t2v-preview',"
                                            + " etc",
                            required = false)
                    String model,
            @ToolParam(
                            name = "negative_prompt",
                            description = "The negative prompt to avoid certain elements",
                            required = false)
                    String negativePrompt,
            @ToolParam(
                            name = "audio_url",
                            description = "The URL for background audio",
                            required = false)
                    String audioUrl,
            @ToolParam(
                            name = "size",
                            description = "Size of the video, e.g., '1920*1080', '1280*720', etc",
                            required = false)
                    String size,
            @ToolParam(
                            name = "duration",
                            description = "Duration of the video in seconds, e.g., '5', '10', etc",
                            required = false)
                    Integer duration,
            @ToolParam(
                            name = "shot_type",
                            description =
                                    "Specify the shot type that generates the video. single:"
                                        + " default value, output single shot video; multi: output"
                                        + " multi-lens video",
                            required = false)
                    String shotType,
            @ToolParam(
                            name = "prompt_extend",
                            description =
                                    "Whether to automatically extend the prompt (default true)",
                            required = false)
                    Boolean promptExtend,
            @ToolParam(
                            name = "watermark",
                            description = "Whether to include watermark (default false)",
                            required = false)
                    Boolean watermark,
            @ToolParam(
                            name = "seed",
                            description = "The seed for reproducibility",
                            required = false)
                    Integer seed) {

        String finalModel =
                Optional.ofNullable(model).filter(s -> !s.trim().isEmpty()).orElse("wan2.6-t2v");
        String finalSize =
                Optional.ofNullable(size).filter(s -> !s.trim().isEmpty()).orElse("1920*1080");
        String finalShotType = Optional.ofNullable(shotType).orElse("single");
        boolean finalPromptExtend = Optional.ofNullable(promptExtend).orElse(true);
        boolean finalWatermark = Optional.ofNullable(watermark).orElse(false);

        log.debug(
                "dashscope_text_to_video called: prompt='{}', model='{}', negativePrompt='{}',"
                    + " audioUrl='{}', size='{}', duration={}, shotType='{}', promptExtend='{}',"
                    + " watermark='{}', seed={}",
                prompt,
                finalModel,
                negativePrompt,
                audioUrl,
                finalSize,
                duration,
                finalShotType,
                finalPromptExtend,
                finalWatermark,
                seed);

        return Mono.fromCallable(
                        () -> {
                            Map<String, Object> parameters = new HashMap<>();
                            parameters.put("size", finalSize);
                            parameters.put("shot_type", finalShotType);
                            parameters.put("prompt_extend", finalPromptExtend);
                            parameters.put("watermark", finalWatermark);
                            if (duration != null) {
                                parameters.put("duration", duration);
                            }
                            if (seed != null) {
                                parameters.put("seed", seed);
                            }

                            VideoSynthesisParam param =
                                    VideoSynthesisParam.builder()
                                            .apiKey(this.apiKey)
                                            .model(finalModel)
                                            .prompt(prompt)
                                            .negativePrompt(negativePrompt)
                                            .audioUrl(audioUrl)
                                            .parameters(parameters)
                                            .header("user-agent", Version.getUserAgent())
                                            .build();

                            VideoSynthesis videoSynthesis = new VideoSynthesis();

                            // The video call method blocks until the video is generated or fails
                            log.info(
                                    "Starting text to video generation task, please wait for a"
                                            + " while...");
                            VideoSynthesisResult response = videoSynthesis.call(param);

                            // Extract video URL from response
                            String videoUrl =
                                    Optional.ofNullable(response)
                                            .map(VideoSynthesisResult::getOutput)
                                            .map(VideoSynthesisOutput::getVideoUrl)
                                            .orElse(null);

                            if (videoUrl == null || videoUrl.trim().isEmpty()) {
                                log.error("No video url returned. Response: {}", response);
                                return ToolResultBlock.error("Failed to generate video.");
                            }

                            log.info("Text to video generated successfully, videoUrl:{}", videoUrl);

                            VideoBlock vb =
                                    VideoBlock.builder()
                                            .source(URLSource.builder().url(videoUrl).build())
                                            .build();

                            return ToolResultBlock.of(vb);
                        })
                .onErrorResume(
                        e -> {
                            log.error("Failed to generate video '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Generate a video based on a single input image (first frame) and an optional text prompt.
     *
     * @param prompt          The text prompt describing the video content and motion.
     * @param model           The model to use, e.g., 'wan2.6-i2v-flash', 'wan2.1-i2v-turbo'.
     * @param imageUrl        The URL, local file path, or Base64 data of the input image (first frame).
     * @param audioUrl        URL of the audio file that the model will use to generate video.
     * @param negativePrompt  The negative prompt to avoid certain elements.
     * @param template        Name of video effect template, e.g., 'squish', 'rotation', etc
     * @param resolution      Resolution of the video, e.g., '720P', '1080P'.
     * @param duration        Duration of the video in seconds (e.g., 5, 10, 15). Default depends on model.
     * @param shotType        Specify the shot type that generates the video.
     *                        single: default value, output single shot video; multi: output multi-lens video.
     * @param audio           Whether to generate audio video (default true).
     * @param promptExtend    Whether to automatically extend the prompt (default true).
     * @param watermark       Whether to include watermark (default false).
     * @param seed            Optional seed for reproducibility.
     * @return A ToolResultBlock containing the generated video url or error message.
     */
    @Tool(
            name = "dashscope_image_to_video",
            description =
                    "Generate a video from a single input image and an optional text prompt."
                            + "Supports optional audio guidance and duration control.")
    public Mono<ToolResultBlock> dashscopeImageToVideo(
            @ToolParam(
                            name = "prompt",
                            description = "Text prompt describing the video content and motion",
                            required = false)
                    String prompt,
            @ToolParam(
                            name = "model",
                            description =
                                    "Model to use, e.g., 'wan2.6-i2v-flash', 'wan2.6-i2v', etc",
                            required = false)
                    String model,
            @ToolParam(
                            name = "image_url",
                            description =
                                    "URL, local file path or Base64 data URL((the format pattern is"
                                        + " data:[MIME_type];base64,{base64_image}, e.g.,"
                                        + " 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABDg...'))"
                                        + " of the first frame image")
                    String imageUrl,
            @ToolParam(
                            name = "audio_url",
                            description =
                                    "URL of the audio file that the model will use to generate"
                                            + " video",
                            required = false)
                    String audioUrl,
            @ToolParam(
                            name = "negative_prompt",
                            description = "The negative prompt to avoid certain elements",
                            required = false)
                    String negativePrompt,
            @ToolParam(
                            name = "template",
                            description =
                                    "Name of video effect template, e.g., 'squish', 'rotation',"
                                            + " etc",
                            required = false)
                    String template,
            @ToolParam(
                            name = "resolution",
                            description = "Video resolution, e.g., '720P', '1080P'",
                            required = false)
                    String resolution,
            @ToolParam(
                            name = "duration",
                            description = "Duration of the video in seconds, e.g., 5, 10, 15",
                            required = false)
                    Integer duration,
            @ToolParam(
                            name = "shot_type",
                            description =
                                    "Specify the shot type that generates the video. single:"
                                        + " default value, output single shot video; multi: output"
                                        + " multi-lens video",
                            required = false)
                    String shotType,
            @ToolParam(
                            name = "audio",
                            description = "Whether to generate audio video (default true)",
                            required = false)
                    Boolean audio,
            @ToolParam(
                            name = "prompt_extend",
                            description =
                                    "Whether to automatically extend the prompt (default true)",
                            required = false)
                    Boolean promptExtend,
            @ToolParam(
                            name = "watermark",
                            description = "Whether to include watermark (default false)",
                            required = false)
                    Boolean watermark,
            @ToolParam(
                            name = "seed",
                            description = "The seed for reproducibility",
                            required = false)
                    Integer seed) {

        String finalModel =
                Optional.ofNullable(model)
                        .filter(s -> !s.trim().isEmpty())
                        .orElse("wan2.6-i2v-flash");
        String finalResolution =
                Optional.ofNullable(resolution).filter(s -> !s.trim().isEmpty()).orElse("720P");
        String finalShotType = Optional.ofNullable(shotType).orElse("single");
        boolean finalAudio = Optional.ofNullable(audio).orElse(true);
        boolean finalPromptExtend = Optional.ofNullable(promptExtend).orElse(true);
        boolean finalWatermark = Optional.ofNullable(watermark).orElse(false);

        log.debug(
                "dashscope_image_to_video called: prompt='{}', model='{}', imageUrl='{}',"
                        + " audioUrl='{}', negativePrompt='{}', template='{}', resolution='{}',"
                        + " duration={}, shotType='{}', audio={}, promptExtend={}, watermark={},"
                        + " seed={}",
                prompt,
                finalModel,
                imageUrl,
                audioUrl,
                negativePrompt,
                template,
                finalResolution,
                duration,
                finalShotType,
                finalAudio,
                finalPromptExtend,
                finalWatermark,
                seed);

        return Mono.fromCallable(
                        () -> {
                            Map<String, Object> parameters = new HashMap<>();
                            parameters.put("resolution", finalResolution);
                            parameters.put("shot_type", finalShotType);
                            parameters.put("audio", finalAudio);
                            parameters.put("prompt_extend", finalPromptExtend);
                            parameters.put("watermark", finalWatermark);
                            if (duration != null) {
                                parameters.put("duration", duration);
                            }
                            if (seed != null) {
                                parameters.put("seed", seed);
                            }

                            VideoSynthesisParam param =
                                    VideoSynthesisParam.builder()
                                            .apiKey(this.apiKey)
                                            .prompt(prompt)
                                            .model(finalModel)
                                            .imgUrl(MediaUtils.urlToProtocolUrl(imageUrl))
                                            .audioUrl(audioUrl)
                                            .negativePrompt(negativePrompt)
                                            .template(template)
                                            .parameters(parameters)
                                            .header("user-agent", Version.getUserAgent())
                                            .build();

                            VideoSynthesis videoSynthesis = new VideoSynthesis();

                            log.info(
                                    "Starting image to video generation task, please wait for a"
                                            + " while...");
                            VideoSynthesisResult response = videoSynthesis.call(param);

                            // Extract video URL from response
                            String videoUrl =
                                    Optional.ofNullable(response)
                                            .map(VideoSynthesisResult::getOutput)
                                            .map(VideoSynthesisOutput::getVideoUrl)
                                            .orElse(null);

                            if (videoUrl == null || videoUrl.trim().isEmpty()) {
                                log.error("Failed to generate video. No video url returned.");
                                return ToolResultBlock.error("Failed to generate video.");
                            }

                            log.info(
                                    "Image to video generated successfully, videoUrl:{}", videoUrl);

                            VideoBlock vb =
                                    VideoBlock.builder()
                                            .source(URLSource.builder().url(videoUrl).build())
                                            .build();

                            return ToolResultBlock.of(vb);
                        })
                .onErrorResume(
                        e -> {
                            log.error("Failed to generate video: '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Generate video transitioning from a first frame to a last frame and an optional text prompt.
     *
     * @param prompt          The text prompt describing the video content and camera movement.
     * @param model           The model to use, e.g., 'wan2.2-kf2v-flash', 'wanx2.1-kf2v-plus'.
     * @param firstFrameUrl   The URL or Base64 data of the first frame image.
     * @param lastFrameUrl    The URL or Base64 data of the last frame image.
     * @param negativePrompt  The negative prompt to avoid certain elements.
     * @param template        Name of video effect template, e.g., 'hanfu-1', 'solaron', etc.
     * @param resolution      Resolution of the video, e.g., '480P', '720P', '1080P'.
     * @param promptExtend    Whether to automatically extend the prompt (default true).
     * @param watermark       Whether to include watermark (default false).
     * @param seed            Optional seed for reproducibility.
     * @return A ToolResultBlock containing the generated video url or error message.
     */
    @Tool(
            name = "dashscope_first_and_last_frame_image_to_video",
            description =
                    "Generate video transitioning from a first frame to a last frame and an"
                            + " optional text prompt")
    public Mono<ToolResultBlock> dashscopeFirstAndLastFrameImageToVideo(
            @ToolParam(
                            name = "prompt",
                            description = "Text prompt describing the video content and motion",
                            required = false)
                    String prompt,
            @ToolParam(
                            name = "model",
                            description =
                                    "Model to use, e.g., 'wan2.2-kf2v-flash', 'wanx2.1-kf2v-plus'",
                            required = false)
                    String model,
            @ToolParam(
                            name = "first_frame_url",
                            description =
                                    "URL, local file path or Base64 data URL(the format pattern is"
                                        + " data:[MIME_type];base64,{base64_image}, e.g.,"
                                        + " 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABDg...')"
                                        + " of the first frame image")
                    String firstFrameUrl,
            @ToolParam(
                            name = "last_frame_url",
                            description =
                                    "URL, local file path or Base64 data URL(the format pattern is"
                                        + " data:[MIME_type];base64,{base64_image}, e.g.,"
                                        + " 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABDg...')"
                                        + " of the last frame image",
                            required = false)
                    String lastFrameUrl,
            @ToolParam(
                            name = "negative_prompt",
                            description = "The negative prompt to avoid certain elements",
                            required = false)
                    String negativePrompt,
            @ToolParam(
                            name = "template",
                            description =
                                    "Name of video effect template, e.g., 'hanfu-1', 'solaron',"
                                            + " etc",
                            required = false)
                    String template,
            @ToolParam(
                            name = "resolution",
                            description = "Video resolution, e.g., '720P', '1080P'",
                            required = false)
                    String resolution,
            @ToolParam(
                            name = "prompt_extend",
                            description =
                                    "Whether to automatically extend the prompt (default true)",
                            required = false)
                    Boolean promptExtend,
            @ToolParam(
                            name = "watermark",
                            description = "Whether to include watermark (default false)",
                            required = false)
                    Boolean watermark,
            @ToolParam(
                            name = "seed",
                            description = "The seed for reproducibility",
                            required = false)
                    Integer seed) {

        String finalModel =
                Optional.ofNullable(model)
                        .filter(s -> !s.trim().isEmpty())
                        .orElse("wan2.2-kf2v-flash");
        String finalResolution =
                Optional.ofNullable(resolution).filter(s -> !s.trim().isEmpty()).orElse("720P");
        boolean finalPromptExtend = Optional.ofNullable(promptExtend).orElse(true);
        boolean finalWatermark = Optional.ofNullable(watermark).orElse(false);

        log.debug(
                "dashscope_first_and_last_frame_image_to_video called: prompt='{}', model='{}',"
                    + " firstFrameUrl='{}', lastFrameUrl='{}', negativePrompt='{}', template='{}',"
                    + " resolution='{}', promptExtend={}, watermark={}, seed={}",
                prompt,
                finalModel,
                firstFrameUrl,
                lastFrameUrl,
                negativePrompt,
                template,
                finalResolution,
                finalPromptExtend,
                finalWatermark,
                seed);

        return Mono.fromCallable(
                        () -> {
                            Map<String, Object> parameters = new HashMap<>();
                            parameters.put("resolution", finalResolution);
                            parameters.put("prompt_extend", finalPromptExtend);
                            parameters.put("watermark", finalWatermark);
                            if (seed != null) {
                                parameters.put("seed", seed);
                            }

                            VideoSynthesisParam param =
                                    VideoSynthesisParam.builder()
                                            .apiKey(this.apiKey)
                                            .model(finalModel)
                                            .prompt(prompt)
                                            .firstFrameUrl(
                                                    MediaUtils.urlToProtocolUrl(firstFrameUrl))
                                            .lastFrameUrl(MediaUtils.urlToProtocolUrl(lastFrameUrl))
                                            .negativePrompt(negativePrompt)
                                            .template(template)
                                            .parameters(parameters)
                                            .header("user-agent", Version.getUserAgent())
                                            .build();

                            VideoSynthesis videoSynthesis = new VideoSynthesis();

                            log.info(
                                    "Starting first and last frame image to video generation task,"
                                            + " please wait for a while...");
                            // The video call method blocks until the video is generated or fails
                            VideoSynthesisResult response = videoSynthesis.call(param);

                            // Extract video URL
                            String videoUrl =
                                    Optional.ofNullable(response)
                                            .map(VideoSynthesisResult::getOutput)
                                            .map(VideoSynthesisOutput::getVideoUrl)
                                            .orElse(null);

                            if (videoUrl == null || videoUrl.trim().isEmpty()) {
                                log.error("Failed to generate video. No URL returned.");
                                return ToolResultBlock.error("Failed to generate video.");
                            }

                            log.info(
                                    "First and last frame image to video video generated"
                                            + " successfully, videoUrl:{}",
                                    videoUrl);

                            VideoBlock vb =
                                    VideoBlock.builder()
                                            .source(URLSource.builder().url(videoUrl).build())
                                            .build();

                            return ToolResultBlock.of(vb);
                        })
                .onErrorResume(
                        e -> {
                            log.error("Failed to generate key-frame video '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }

    /**
     * Analyze video and generate a text description or answer questions based on the video content.
     *
     * @param videoUrl      The URL or local path of the video to analyze.
     * @param prompt        The text prompt or question regarding the video content.
     * @param model         The vision model to use, e.g., 'qwen3.5-plus', 'qwen3.5-flash', 'qwen3-vl-plus', 'qwen3-vl-flash', etc.
     * @param fps           Frames per second to sample from the video (e.g., 1, 2, 4). Default is 2.
     * @return A ToolResultBlock containing the generated text analysis or error message.
     */
    @Tool(
            name = "dashscope_video_to_text",
            description =
                    "Analyze video and generate a text description or answer questions based on the"
                            + " video content.Supports controlling the frame sampling rate (fps).")
    public Mono<ToolResultBlock> dashscopeVideoToText(
            @ToolParam(
                            name = "video_url",
                            description =
                                    "The URL, local file path or base64 data URL(the format pattern"
                                        + " is data:[MIME_type];base64,{base64_video}, e.g.,"
                                        + " 'data:video/mp4;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAA...')"
                                        + " of the video to analyze.")
                    String videoUrl,
            @ToolParam(
                            name = "prompt",
                            description = "The question or instruction regarding the video content",
                            required = false)
                    String prompt,
            @ToolParam(
                            name = "model",
                            description =
                                    "The vision model to use, e.g., 'qwen3.5-plus',"
                                            + " 'qwen3.5-flash', 'qwen3-vl-plus', 'qwen3-vl-flash',"
                                            + " etc",
                            required = false)
                    String model,
            @ToolParam(
                            name = "fps",
                            description =
                                    "Frames per second to sample from the video for analysis"
                                            + " (default 2.0)",
                            required = false)
                    Double fps) {

        String finalModel =
                Optional.ofNullable(model).filter(s -> !s.trim().isEmpty()).orElse("qwen3.5-plus");
        String finalPrompt =
                Optional.ofNullable(prompt)
                        .filter(s -> !s.trim().isEmpty())
                        .orElse("Describe the video");
        double finalFps = Optional.ofNullable(fps).orElse(2.0);

        log.debug(
                "dashscope_video_to_text called: videoUrl:'{}', prompt='{}', model='{}', fps={}",
                videoUrl,
                prompt,
                finalModel,
                finalFps);

        return Mono.fromCallable(
                        () -> {
                            Map<String, Object> videoParams = new HashMap<>();
                            videoParams.put("video", MediaUtils.urlToProtocolUrl(videoUrl));
                            videoParams.put("fps", finalFps);
                            List<Map<String, Object>> content = new ArrayList<>();
                            content.add(Map.of("text", finalPrompt));
                            content.add(videoParams);
                            MultiModalMessage userMessage =
                                    MultiModalMessage.builder()
                                            .role(Role.USER.getValue())
                                            .content(content)
                                            .build();

                            MultiModalMessage systemMessage =
                                    MultiModalMessage.builder()
                                            .role(Role.SYSTEM.getValue())
                                            .content(
                                                    List.of(
                                                            Map.of(
                                                                    "text",
                                                                    "You are a helpful"
                                                                            + " assistant.")))
                                            .build();

                            List<MultiModalMessage> multiModalMessages = new ArrayList<>();
                            multiModalMessages.add(systemMessage);
                            multiModalMessages.add(userMessage);

                            MultiModalConversationParam param =
                                    MultiModalConversationParam.builder()
                                            .apiKey(this.apiKey)
                                            .model(finalModel)
                                            .messages(multiModalMessages)
                                            .header("user-agent", Version.getUserAgent())
                                            .build();

                            MultiModalConversation conv = new MultiModalConversation();
                            MultiModalConversationResult result = conv.call(param);

                            // Extract text from the result
                            String text =
                                    Optional.ofNullable(result)
                                            .map(MultiModalConversationResult::getOutput)
                                            .map(MultiModalConversationOutput::getChoices)
                                            .flatMap(choices -> choices.stream().findFirst())
                                            .map(MultiModalConversationOutput.Choice::getMessage)
                                            .map(MultiModalMessage::getContent)
                                            .flatMap(contents -> contents.stream().findFirst())
                                            .map(contentMap -> contentMap.get("text"))
                                            .map(Object::toString)
                                            .orElse(null);

                            if (text == null || text.trim().isEmpty()) {
                                log.error("Failed to analyze video. No text response returned.");
                                return ToolResultBlock.error("Failed to analyze video.");
                            }

                            log.info("Video analysis completed successfully.");

                            TextBlock tb = TextBlock.builder().text(text).build();
                            return ToolResultBlock.of(tb);
                        })
                .onErrorResume(
                        e -> {
                            log.error("Failed to analyze video '{}'", e.getMessage(), e);
                            return Mono.just(ToolResultBlock.error(e.getMessage()));
                        });
    }
}
