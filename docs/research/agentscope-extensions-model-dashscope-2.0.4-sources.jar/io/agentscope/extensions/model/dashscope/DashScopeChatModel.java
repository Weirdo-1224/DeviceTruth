/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.extensions.model.dashscope;

import io.agentscope.core.formatter.Formatter;
import io.agentscope.core.message.Msg;
import io.agentscope.core.model.ChatModelBase;
import io.agentscope.core.model.ChatResponse;
import io.agentscope.core.model.GenerateOptions;
import io.agentscope.core.model.ModelContextWindows;
import io.agentscope.core.model.ModelException;
import io.agentscope.core.model.ModelUtils;
import io.agentscope.core.model.ToolChoice;
import io.agentscope.core.model.ToolSchema;
import io.agentscope.core.model.transport.HttpTransport;
import io.agentscope.core.model.transport.HttpTransportConfig;
import io.agentscope.core.model.transport.HttpTransportFactory;
import io.agentscope.core.model.transport.OkHttpTransport;
import io.agentscope.core.model.transport.ProxyConfig;
import io.agentscope.extensions.model.dashscope.dto.DashScopeMessage;
import io.agentscope.extensions.model.dashscope.dto.DashScopeRequest;
import io.agentscope.extensions.model.dashscope.dto.DashScopeResponse;
import io.agentscope.extensions.model.dashscope.formatter.DashScopeChatFormatter;
import io.agentscope.extensions.model.dashscope.formatter.DashScopeMultiAgentFormatter;
import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

/**
 * DashScope Chat Model using native HTTP API.
 *
 * <p>This implementation uses direct HTTP calls to DashScope API via OkHttp,
 * without depending on the DashScope Java SDK.
 *
 * <p>Supports both text and vision models through automatic endpoint routing.
 * Use {@link EndpointType} to explicitly control the endpoint selection.
 *
 * <p>Features:
 * <ul>
 *   <li>Streaming and non-streaming modes</li>
 *   <li>Tool calling support</li>
 *   <li>Thinking mode support</li>
 *   <li>Automatic message format conversion</li>
 *   <li>Timeout and retry configuration</li>
 * </ul>
 */
public class DashScopeChatModel extends ChatModelBase {

    private static final Logger log = LoggerFactory.getLogger(DashScopeChatModel.class);

    private final String modelName;
    private final boolean stream;
    private final Boolean enableThinking; // nullable
    private final Boolean enableSearch; // nullable
    private final EndpointType endpointType;
    private final GenerateOptions defaultOptions;
    private final Formatter<DashScopeMessage, DashScopeResponse, DashScopeRequest> formatter;

    // HTTP client for API calls
    private final DashScopeHttpClient httpClient;

    /**
     * Creates a new DashScope chat model instance with automatic API type detection.
     *
     * <p>This constructor maintains backward compatibility. API type defaults to AUTO,
     * which detects the endpoint based on model name.
     *
     * @param apiKey the API key for DashScope authentication
     * @param modelName the model name (e.g., "qwen-max", "qwen-vl-plus")
     * @param stream whether streaming should be enabled
     * @param enableThinking whether thinking mode should be enabled (null for disabled)
     * @param enableSearch whether search enhancement should be enabled (null for disabled)
     * @param defaultOptions default generation options (null for defaults)
     * @param baseUrl custom base URL for DashScope API (null for default)
     * @param formatter the message formatter to use (null for default DashScope formatter)
     * @param httpTransport custom HTTP transport (null for default from factory)
     * @param publicKeyId the RSA public key ID for encryption (null to disable encryption)
     * @param publicKey the RSA public key for encryption (Base64-encoded, null to disable encryption)
     */
    public DashScopeChatModel(
            String apiKey,
            String modelName,
            boolean stream,
            Boolean enableThinking,
            Boolean enableSearch,
            GenerateOptions defaultOptions,
            String baseUrl,
            Formatter<DashScopeMessage, DashScopeResponse, DashScopeRequest> formatter,
            HttpTransport httpTransport,
            String publicKeyId,
            String publicKey) {
        this(
                apiKey,
                modelName,
                stream,
                enableThinking,
                enableSearch,
                null,
                defaultOptions,
                baseUrl,
                formatter,
                httpTransport,
                publicKeyId,
                publicKey);
    }

    /**
     * Creates a new DashScope chat model instance with explicit API type.
     *
     * @param apiKey the API key for DashScope authentication
     * @param modelName the model name (e.g., "qwen-max", "qwen-vl-plus")
     * @param stream whether streaming should be enabled
     * @param enableThinking whether thinking mode should be enabled (null for disabled)
     * @param enableSearch whether search enhancement should be enabled (null for disabled)
     * @param endpointType the endpoint type to use (null for AUTO detection)
     * @param defaultOptions default generation options (null for defaults)
     * @param baseUrl custom base URL for DashScope API (null for default)
     * @param formatter the message formatter to use (null for default DashScope formatter)
     * @param httpTransport custom HTTP transport (null for default from factory)
     * @param publicKeyId the RSA public key ID for encryption (null to disable encryption)
     * @param publicKey the RSA public key for encryption (Base64-encoded, null to disable encryption)
     */
    public DashScopeChatModel(
            String apiKey,
            String modelName,
            boolean stream,
            Boolean enableThinking,
            Boolean enableSearch,
            EndpointType endpointType,
            GenerateOptions defaultOptions,
            String baseUrl,
            Formatter<DashScopeMessage, DashScopeResponse, DashScopeRequest> formatter,
            HttpTransport httpTransport,
            String publicKeyId,
            String publicKey) {
        this(
                apiKey,
                modelName,
                stream,
                enableThinking,
                enableSearch,
                endpointType,
                defaultOptions,
                baseUrl,
                formatter,
                httpTransport,
                publicKeyId,
                publicKey,
                null);
    }

    /**
     * Creates a new DashScope chat model instance with explicit API type and additional
     * multimodal model patterns.
     *
     * @param apiKey the API key for DashScope authentication
     * @param modelName the model name (e.g., "qwen-max", "qwen-vl-plus")
     * @param stream whether streaming should be enabled
     * @param enableThinking whether thinking mode should be enabled (null for disabled)
     * @param enableSearch whether search enhancement should be enabled (null for disabled)
     * @param endpointType the endpoint type to use (null for AUTO detection)
     * @param defaultOptions default generation options (null for defaults)
     * @param baseUrl custom base URL for DashScope API (null for default)
     * @param formatter the message formatter to use (null for default DashScope formatter)
     * @param httpTransport custom HTTP transport (null for default from factory)
     * @param publicKeyId the RSA public key ID for encryption (null to disable encryption)
     * @param publicKey the RSA public key for encryption (Base64-encoded, null to disable encryption)
     * @param multimodalModelPatterns case-insensitive substring patterns that extend the
     *     built-in multimodal model detection when endpointType is AUTO (null to disable)
     */
    public DashScopeChatModel(
            String apiKey,
            String modelName,
            boolean stream,
            Boolean enableThinking,
            Boolean enableSearch,
            EndpointType endpointType,
            GenerateOptions defaultOptions,
            String baseUrl,
            Formatter<DashScopeMessage, DashScopeResponse, DashScopeRequest> formatter,
            HttpTransport httpTransport,
            String publicKeyId,
            String publicKey,
            Collection<String> multimodalModelPatterns) {
        this.modelName = modelName;
        // DashScope only rejects the non-streaming + thinking combination for some open-source
        // thinking models.
        this.stream = stream;
        this.enableThinking = enableThinking;
        this.enableSearch = enableSearch;
        this.endpointType = endpointType != null ? endpointType : EndpointType.AUTO;
        this.defaultOptions =
                defaultOptions != null ? defaultOptions : GenerateOptions.builder().build();
        this.formatter = formatter != null ? formatter : new DashScopeChatFormatter();

        // Initialize HTTP client with provided transport or factory default
        HttpTransport transport =
                httpTransport != null ? httpTransport : HttpTransportFactory.getDefault();
        this.httpClient =
                DashScopeHttpClient.builder()
                        .transport(transport)
                        .apiKey(apiKey)
                        .baseUrl(baseUrl)
                        .publicKeyId(publicKeyId)
                        .publicKey(publicKey)
                        .multimodalModelPatterns(multimodalModelPatterns)
                        .build();
    }

    /**
     * Creates a new builder for DashScopeChatModel.
     *
     * @return a new Builder instance
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Stream chat completion responses from DashScope's API.
     *
     * <p>This method automatically routes to the appropriate API based on the model name:
     * <ul>
     *   <li>Vision models (qvq* or *-vl*) → MultiModal API</li>
     *   <li>Text models → Text Generation API</li>
     * </ul>
     *
     * <p>Supports timeout and retry configuration through GenerateOptions.
     *
     * @param messages AgentScope messages to send to the model
     * @param tools Optional list of tool schemas
     * @param options Optional generation options (null to use defaults)
     * @return Flux stream of chat responses
     */
    @Override
    protected Flux<ChatResponse> doStream(
            List<Msg> messages, List<ToolSchema> tools, GenerateOptions options) {

        if (log.isDebugEnabled()) {
            boolean useMultimodal = httpClient.requiresMultimodalApi(modelName, endpointType);
            log.debug(
                    "DashScope API call: model={}, endpointType={}, multimodal={}",
                    modelName,
                    endpointType,
                    useMultimodal);
        }

        Flux<ChatResponse> responseFlux = streamWithHttpClient(messages, tools, options);

        // Apply timeout and retry if configured
        return ModelUtils.applyTimeoutAndRetry(
                responseFlux, options, defaultOptions, modelName, "dashscope");
    }

    /**
     * Stream using HTTP client.
     *
     * <p>This method uses the native DashScope HTTP API directly via OkHttp.
     */
    private Flux<ChatResponse> streamWithHttpClient(
            List<Msg> messages, List<ToolSchema> tools, GenerateOptions options) {
        Instant start = Instant.now();
        boolean useMultimodal = httpClient.requiresMultimodalApi(modelName, endpointType);

        // Merge options with defaultOptions (options takes precedence)
        GenerateOptions effectiveOptions = GenerateOptions.mergeOptions(options, defaultOptions);
        ToolChoice toolChoice = effectiveOptions.getToolChoice();

        // Format messages using formatter
        List<DashScopeMessage> dashScopeMessages;
        if (useMultimodal) {
            if (formatter instanceof DashScopeChatFormatter chatFormatter) {
                dashScopeMessages = chatFormatter.formatMultiModal(messages, effectiveOptions);
            } else if (formatter instanceof DashScopeMultiAgentFormatter multiAgentFormatter) {
                dashScopeMessages =
                        multiAgentFormatter.formatMultiModal(messages, effectiveOptions);
            } else {
                throw new IllegalStateException(
                        "DashScope vision models require DashScopeChatFormatter or"
                                + " DashScopeMultiAgentFormatter, but got: "
                                + formatter.getClass().getName());
            }
        } else {
            dashScopeMessages = formatter.format(messages, effectiveOptions);
        }

        // Build request using formatter
        DashScopeRequest request;
        if (formatter instanceof DashScopeChatFormatter chatFormatter) {
            request =
                    chatFormatter.buildRequest(
                            modelName,
                            dashScopeMessages,
                            stream,
                            options,
                            defaultOptions,
                            tools,
                            toolChoice);
        } else if (formatter instanceof DashScopeMultiAgentFormatter multiAgentFormatter) {
            request = multiAgentFormatter.buildRequest(modelName, dashScopeMessages, stream);
            // Apply options and tools manually for multi-agent formatter
            multiAgentFormatter.applyOptions(request, options, defaultOptions);
            multiAgentFormatter.applyTools(request, tools);
            multiAgentFormatter.applyToolChoice(request, toolChoice);
        } else {
            throw new IllegalStateException(
                    "Unsupported formatter type: " + formatter.getClass().getName());
        }

        // Apply thinking mode if enabled
        applyThinkingMode(request, effectiveOptions);

        // Set endpoint type for endpoint selection
        request.setEndpointType(endpointType);

        if (stream) {
            // Streaming mode
            return httpClient.stream(
                            request,
                            effectiveOptions.getAdditionalHeaders(),
                            effectiveOptions.getAdditionalBodyParams(),
                            effectiveOptions.getAdditionalQueryParams())
                    .map(response -> formatter.parseResponse(response, start));
        } else {
            // Non-streaming mode
            return Flux.defer(
                            () -> {
                                try {
                                    DashScopeResponse response =
                                            httpClient.call(
                                                    request,
                                                    effectiveOptions.getAdditionalHeaders(),
                                                    effectiveOptions.getAdditionalBodyParams(),
                                                    effectiveOptions.getAdditionalQueryParams());
                                    ChatResponse chatResponse =
                                            formatter.parseResponse(response, start);
                                    return Flux.just(chatResponse);
                                } catch (Exception e) {
                                    log.error("DashScope HTTP client error: {}", e.getMessage(), e);
                                    return Flux.error(
                                            new ModelException(
                                                    "DashScope API call failed: " + e.getMessage(),
                                                    e));
                                }
                            })
                    .subscribeOn(Schedulers.boundedElastic());
        }
    }

    /**
     * Apply thinking mode configuration to request if enabled.
     */
    private void applyThinkingMode(DashScopeRequest request, GenerateOptions options) {
        // Validate thinking configuration
        if (options.getThinkingBudget() != null && !Boolean.TRUE.equals(enableThinking)) {
            throw new IllegalStateException(
                    "thinkingBudget is set but enableThinking is not enabled. To use thinking mode"
                        + " with budget control, you must explicitly enable thinking by calling"
                        + " .enableThinking(true) on the model builder. Example:"
                        + " DashScopeChatModel.builder().enableThinking(true)"
                        + ".defaultOptions(GenerateOptions.builder().thinkingBudget(1000).build())");
        }

        if (enableThinking != null) {
            // Explicitly assign value for thinking mode
            request.getParameters().setEnableThinking(enableThinking);
        }

        if (Boolean.TRUE.equals(enableThinking) && options.getThinkingBudget() != null) {
            request.getParameters().setThinkingBudget(options.getThinkingBudget());
        }

        if (Boolean.TRUE.equals(enableThinking)) {
            degradeForcedToolChoiceForThinkingMode(request);
        }

        // Model-specific settings for search mode
        if (enableSearch != null) {
            // Explicitly assign value for search mode
            request.getParameters().setEnableSearch(enableSearch);
        }
    }

    /**
     * DashScope thinking mode does not support forced tool_choice values such as required/object.
     * Degrade them to auto so structured-output retries can continue without a 400 response.
     */
    private void degradeForcedToolChoiceForThinkingMode(DashScopeRequest request) {
        if (request == null || request.getParameters() == null) {
            return;
        }

        Object toolChoice = request.getParameters().getToolChoice();
        if (!(toolChoice instanceof Map<?, ?>)) {
            return;
        }

        log.warn(
                "DashScope thinking mode does not support forced tool_choice values; degrading to"
                        + " 'auto'");
        request.getParameters().setToolChoice("auto");
    }

    /**
     * Gets the model name for logging and identification.
     *
     * @return the model name
     */
    @Override
    public String getModelName() {
        return modelName;
    }

    @Override
    public boolean supportsNativeStructuredOutput() {
        if (Boolean.TRUE.equals(enableThinking)) {
            return false;
        }
        return super.supportsNativeStructuredOutput();
    }

    public static class Builder {
        private String apiKey;
        private String modelName;
        private boolean stream = true;
        private Boolean enableThinking;
        private Boolean enableSearch;
        private EndpointType endpointType;
        private GenerateOptions defaultOptions = null;
        private String baseUrl;
        private Formatter<DashScopeMessage, DashScopeResponse, DashScopeRequest> formatter;
        private HttpTransport httpTransport;
        private boolean enableEncrypt = false;
        private ProxyConfig proxyConfig;
        private int contextWindowSize = -1;
        private Boolean nativeStructuredOutput;
        private Boolean nativeStructuredOutputWithTools;
        private Collection<String> multimodalModelPatterns;

        /**
         * Sets the API key for DashScope authentication.
         *
         * @param apiKey the API key
         * @return this builder instance
         */
        public Builder apiKey(String apiKey) {
            this.apiKey = apiKey;
            return this;
        }

        /**
         * Sets the model name to use.
         *
         * <p>The model name determines which API is used when endpointType is AUTO.
         *
         * @param modelName the model name (e.g., "qwen-max", "qwen-vl-plus")
         * @return this builder instance
         * @see DashScopeHttpClient#isMultimodalModel(String)
         */
        public Builder modelName(String modelName) {
            this.modelName = modelName;
            return this;
        }

        /**
         * Sets whether streaming should be enabled.
         *
         * @param stream true to enable streaming, false for non-streaming
         * @return this builder instance
         */
        public Builder stream(boolean stream) {
            this.stream = stream;
            return this;
        }

        /**
         * Sets whether thinking mode should be enabled.
         *
         * @param enableThinking true to enable thinking mode, false to disable, null for default
         * @return this builder instance
         */
        public Builder enableThinking(Boolean enableThinking) {
            this.enableThinking = enableThinking;
            return this;
        }

        /**
         * Sets whether search enhancement should be enabled.
         *
         * <p>When enabled, the model can access internet search to provide more up-to-date
         * and accurate responses.
         *
         * @param enableSearch true to enable search mode, false to disable, null for default (disabled)
         * @return this builder instance
         */
        public Builder enableSearch(Boolean enableSearch) {
            this.enableSearch = enableSearch;
            return this;
        }

        /**
         * Sets the endpoint type to use for endpoint routing.
         *
         * @param endpointType the endpoint type to use (null for AUTO)
         * @return this builder instance
         * @see EndpointType
         * @see DashScopeHttpClient#isMultimodalModel(String)
         */
        public Builder endpointType(EndpointType endpointType) {
            this.endpointType = endpointType;
            return this;
        }

        /**
         * Sets the default generation options.
         *
         * @param options the default options to use (null for defaults)
         * @return this builder instance
         */
        public Builder defaultOptions(GenerateOptions options) {
            this.defaultOptions = options;
            return this;
        }

        /**
         * Sets a custom base URL for DashScope API.
         *
         * @param baseUrl the base URL (null for default)
         * @return this builder instance
         */
        public Builder baseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
            return this;
        }

        /**
         * Sets the message formatter to use.
         *
         * @param formatter the formatter (null for default DashScope formatter)
         * @return this builder instance
         */
        public Builder formatter(
                Formatter<DashScopeMessage, DashScopeResponse, DashScopeRequest> formatter) {
            this.formatter = formatter;
            return this;
        }

        /**
         * Sets the HTTP transport to use.
         *
         * <p>If not set, the default transport from {@link HttpTransportFactory} will be used.
         * This allows sharing a single transport instance across multiple models for better
         * resource management.
         *
         * <p>Example:
         * <pre>{@code
         * HttpTransport custom = OkHttpTransport.builder()
         *     .config(HttpTransportConfig.builder()
         *         .connectTimeout(Duration.ofSeconds(30))
         *         .build())
         *     .build();
         *
         * DashScopeChatModel model = DashScopeChatModel.builder()
         *     .apiKey("xxx")
         *     .modelName("qwen-plus")
         *     .httpTransport(custom)
         *     .build();
         * }</pre>
         *
         * <p><b>Note on proxy configuration:</b> Because {@code httpTransport} is a
         * fully-constructed HTTP client instance, its configuration (including proxy)
         * cannot be modified after creation. If you need to configure a proxy, either:
         *
         * <ul>
         *   <li>Use {@link #proxy(ProxyConfig)} without calling {@code httpTransport()},
         *       for simple proxy-only customization.
         *   <li>Configure the proxy directly within the transport's
         *       {@link HttpTransportConfig} when building the transport instance.
         * </ul>
         *
         * <p>If both {@code httpTransport()} and {@code proxy()} are called,
         * {@code httpTransport()} takes full precedence and {@code proxy()} is ignored
         * (a warning is logged at build time).
         *
         * @param httpTransport the HTTP transport (null for default from factory)
         * @return this builder instance
         */
        public Builder httpTransport(HttpTransport httpTransport) {
            this.httpTransport = httpTransport;
            return this;
        }

        /**
         * Sets the proxy configuration for HTTP traffic.
         *
         * <p><b>Interaction with {@link #httpTransport(HttpTransport)}:</b>
         * Because {@code httpTransport} is a fully-constructed HTTP client instance,
         * its configuration cannot be modified after creation. The final transport is
         * determined as follows:
         *
         * <ul>
         *   <li>If only {@code proxy()} is called: the default {@link OkHttpTransport}
         *       is used with the specified proxy configuration applied.
         *   <li>If only {@code httpTransport()} is called: the provided transport is
         *       used as-is (proxy must be configured within the transport's own
         *       {@link HttpTransportConfig}).
         *   <li>If <i>both</i> are called: {@code httpTransport()} takes full precedence.
         *       The {@code proxy()} setting is <b>ignored</b> and a warning is logged.
         *       To configure proxy with a custom transport, set it within the transport's
         *       {@link HttpTransportConfig} directly.
         *   <li>If neither is called: the default transport from {@link HttpTransportFactory}
         *       is used (no proxy).
         * </ul>
         *
         * @param proxyConfig the proxy configuration (see {@link ProxyConfig})
         * @return this builder instance
         */
        public Builder proxy(ProxyConfig proxyConfig) {
            this.proxyConfig = proxyConfig;
            return this;
        }

        /**
         * Sets whether encryption should be enabled.
         *
         * <p>When enabled, the model will automatically fetch the latest RSA public key from
         * DashScope API and use it to encrypt requests and responses using AES-GCM with RSA key
         * exchange, following Aliyun's encryption protocol. This enables secure access to Aliyun
         * models while complying with enterprise security policies (e.g., TLS encryption,
         * token-based authentication).
         *
         * <p>If fetching the public key fails during build(), an exception will be thrown to
         * prevent creating a model with incorrect encryption configuration.
         *
         * <p>Example:
         * <pre>{@code
         * DashScopeChatModel model = DashScopeChatModel.builder()
         *     .apiKey("sk-xxx")
         *     .modelName("qwen-max")
         *     .enableEncrypt(true)
         *     .build();
         * }</pre>
         *
         * @param enableEncrypt true to enable encryption (will fetch public key automatically),
         *     false to disable encryption
         * @return this builder instance
         */
        public Builder enableEncrypt(boolean enableEncrypt) {
            this.enableEncrypt = enableEncrypt;
            return this;
        }

        /**
         * Overrides the inferred context window size (in tokens). When not set ({@code -1}),
         * the size is inferred from the model name using a built-in lookup table.
         */
        public Builder contextWindowSize(int contextWindowSize) {
            this.contextWindowSize = contextWindowSize;
            return this;
        }

        /**
         * Sets whether this model supports native structured output via {@code response_format}
         * with {@code json_schema} type.
         *
         * <p>Defaults to {@code false}. DashScope's native endpoint only supports
         * {@code json_object} (free-form JSON), not {@code json_schema} (strict schema
         * validation). When {@code false}, the framework uses the {@code generate_response}
         * tool fallback for structured output requests.
         *
         * <p>Set to {@code true} only if your model/endpoint is confirmed to support
         * {@code json_schema} in {@code response_format}.
         *
         * @param nativeStructuredOutput true to enable native json_schema path
         * @return this builder instance
         */
        public Builder nativeStructuredOutput(boolean nativeStructuredOutput) {
            this.nativeStructuredOutput = nativeStructuredOutput;
            return this;
        }

        /**
         * Sets whether this model correctly handles native structured output
         * ({@code response_format}) alongside tool calling.
         *
         * <p>Defaults to {@code false} (inherits from
         * {@link #nativeStructuredOutput(boolean)}). Set to {@code true} only for models
         * that support both {@code response_format} and tool calling simultaneously.
         *
         * @param nativeStructuredOutputWithTools false to use fallback when tools are present
         * @return this builder instance
         */
        public Builder nativeStructuredOutputWithTools(boolean nativeStructuredOutputWithTools) {
            this.nativeStructuredOutputWithTools = nativeStructuredOutputWithTools;
            return this;
        }

        /**
         * Sets additional case-insensitive substring patterns for multimodal model detection.
         *
         * <p>When {@link EndpointType#AUTO} is used, a model name matching any of these
         * patterns (as a substring, case-insensitively) is routed to the multimodal
         * generation API, in addition to the built-in model-name rules of
         * {@link DashScopeHttpClient#isMultimodalModel(String)}. This lets you use
         * multimodal models not yet covered by the built-in whitelist (e.g.
         * {@code "deepseek-v4.1"}) without waiting for a framework update.
         *
         * <p>Example:
         * <pre>{@code
         * DashScopeChatModel model = DashScopeChatModel.builder()
         *     .apiKey("sk-xxx")
         *     .modelName("deepseek-v4.1")
         *     .multimodalModelPatterns(List.of("deepseek-v4"))
         *     .build();
         * }</pre>
         *
         * @param multimodalModelPatterns case-insensitive substring patterns (may be null)
         * @return this builder instance
         * @see DashScopeHttpClient.Builder#multimodalModelPatterns(Collection)
         */
        public Builder multimodalModelPatterns(Collection<String> multimodalModelPatterns) {
            this.multimodalModelPatterns = multimodalModelPatterns;
            return this;
        }

        /**
         * Builds the DashScopeChatModel instance.
         *
         * <p>This method ensures that the defaultOptions always has proper executionConfig
         * applied.
         *
         * <p>If encryption is enabled, this method will automatically fetch the public key
         * from DashScope API. If the fetch fails, an exception will be thrown.
         *
         * <p><b>Proxy resolution:</b> If both {@link #proxy(ProxyConfig)} and
         * {@link #httpTransport(HttpTransport)} are set, {@code httpTransport()} takes
         * precedence and a warning is logged. Otherwise, the proxy is applied to a default
         * transport, or the factory default is used.
         *
         * @return configured DashScopeChatModel instance
         * @throws DashScopeHttpClient.DashScopeHttpException if encryption is enabled and
         *     public key fetching fails
         */
        public DashScopeChatModel build() {
            GenerateOptions effectiveOptions =
                    ModelUtils.ensureDefaultExecutionConfig(defaultOptions);

            String finalPublicKeyId = null;
            String finalPublicKey = null;

            HttpTransport transport = resolveTransport();

            if (enableEncrypt) {
                DashScopeHttpClient.PublicKeyResult publicKeyResult =
                        DashScopeHttpClient.fetchPublicKey(apiKey, baseUrl, transport);
                finalPublicKeyId = publicKeyResult.publicKeyId();
                finalPublicKey = publicKeyResult.publicKey();
            }

            DashScopeChatModel model =
                    new DashScopeChatModel(
                            apiKey,
                            modelName,
                            stream,
                            enableThinking,
                            enableSearch,
                            endpointType,
                            effectiveOptions,
                            baseUrl,
                            formatter,
                            transport,
                            finalPublicKeyId,
                            finalPublicKey,
                            multimodalModelPatterns);
            model.setContextWindowSize(
                    contextWindowSize >= 0
                            ? contextWindowSize
                            : ModelContextWindows.lookup(modelName, ModelContextWindows.DASHSCOPE));
            if (nativeStructuredOutput != null) {
                model.setNativeStructuredOutput(nativeStructuredOutput);
            }
            if (nativeStructuredOutputWithTools != null) {
                model.setNativeStructuredOutputWithTools(nativeStructuredOutputWithTools);
            }
            return model;
        }

        /**
         * Resolves the final HttpTransport to use.
         *
         * <p>If {@code httpTransport()} is set, it takes full precedence and
         * {@code proxyConfig} is ignored (with a warning logged). Otherwise,
         * if {@code proxy()} is set, a default transport with the proxy applied
         * is created. If neither is set, the factory default is used.
         *
         * @return the resolved HttpTransport
         */
        private HttpTransport resolveTransport() {
            if (httpTransport != null) {
                if (proxyConfig != null) {
                    log.warn(
                            "DashScopeChatModel: both proxy() and httpTransport() are set. "
                                    + "httpTransport() takes precedence, proxy() is ignored. "
                                    + "To configure proxy, use one of the following:\n"
                                    + "  1. Simple: only call proxy() without httpTransport()\n"
                                    + "  2. Advanced: set proxy in HttpTransportConfig when "
                                    + "building a custom HttpTransport");
                }
                return httpTransport;
            }

            if (proxyConfig != null) {
                // Only proxy() called → use default transport with proxy
                return OkHttpTransport.builder()
                        .config(HttpTransportConfig.builder().proxy(proxyConfig).build())
                        .build();
            }

            // Neither called → use factory default
            return HttpTransportFactory.getDefault();
        }
    }
}
