/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.core.tool;

import io.agentscope.core.util.JsonSchemaUtils;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Generates JSON Schema for tool parameters.
 * This class handles the conversion of Java method signatures to JSON Schema
 * format
 * compatible with OpenAI's function calling API.
 */
class ToolSchemaGenerator {

    /**
     * Generate parameter schema for a method with excluded parameters.
     *
     * <p>
     * This overload allows excluding certain parameters from the generated schema,
     * which is
     * useful for preset parameters that should not be exposed to the agent.
     *
     * @param method        the method to generate schema for
     * @param excludeParams set of parameter names to exclude from the schema (may
     *                      be null or empty)
     * @return JSON Schema map in OpenAI format
     */
    @SuppressWarnings("unchecked")
    Map<String, Object> generateParameterSchema(Method method, Set<String> excludeParams) {
        Map<String, Object> schema = new HashMap<>();
        schema.put("type", "object");

        Map<String, Object> properties = new HashMap<>();
        List<String> required = new ArrayList<>();
        Map<String, Object> allDefs = new HashMap<>();

        Parameter[] parameters = method.getParameters();
        for (Parameter param : parameters) {
            // Only include parameters with @ToolParam annotation
            ToolParam toolParam = param.getAnnotation(ToolParam.class);
            if (toolParam == null) {
                continue;
            }

            ParameterInfo info = extractParameterInfo(param, toolParam);

            // Skip excluded parameters (e.g., preset parameters)
            if (excludeParams != null && excludeParams.contains(info.name)) {
                continue;
            }

            // Hoist $defs from per-parameter schema to the root level so that
            // $ref pointers like "#/$defs/TypeName" resolve against the document root.
            hoistDefs(info.schema, "$defs", allDefs);
            hoistDefs(info.schema, "definitions", allDefs);

            properties.put(info.name, info.schema);
            if (info.required) {
                required.add(info.name);
            }
        }

        schema.put("properties", properties);
        if (!required.isEmpty()) {
            schema.put("required", required);
        }
        if (!allDefs.isEmpty()) {
            schema.put("$defs", allDefs);
        }

        return schema;
    }

    @SuppressWarnings("unchecked")
    private void hoistDefs(
            Map<String, Object> paramSchema, String key, Map<String, Object> target) {
        Object raw = paramSchema.remove(key);
        if (raw instanceof Map<?, ?> defs && !defs.isEmpty()) {
            Map<String, Object> normalizedDefs = (Map<String, Object>) defs;
            for (Map.Entry<String, Object> entry : normalizedDefs.entrySet()) {
                String defKey = entry.getKey();
                Object incomingDef = entry.getValue();
                Object existingDef = target.get(defKey);
                if (existingDef == null) {
                    target.put(defKey, incomingDef);
                    continue;
                }
                if (!Objects.equals(existingDef, incomingDef)) {
                    throw new IllegalStateException(
                            "Conflicting schema definition found for key: " + defKey);
                }
            }
        }
    }

    /**
     * Extract parameter information from a Parameter with @ToolParam annotation.
     *
     * @param param the parameter to extract info from
     * @param toolParam the @ToolParam annotation
     * @return ParameterInfo containing name, schema, and required flag
     */
    private ParameterInfo extractParameterInfo(Parameter param, ToolParam toolParam) {
        String paramName = toolParam.name();

        // Generate schema using JsonSchemaUtils with full type support (including generics)
        Map<String, Object> paramSchema =
                JsonSchemaUtils.generateSchemaFromType(param.getParameterizedType());

        if (!toolParam.description().isEmpty()) {
            paramSchema.put("description", toolParam.description());
        }

        return new ParameterInfo(paramName, paramSchema, toolParam.required());
    }

    /**
     * Internal class to hold parameter information.
     */
    private static class ParameterInfo {
        final String name;
        final Map<String, Object> schema;
        final boolean required;

        ParameterInfo(String name, Map<String, Object> schema, boolean required) {
            this.name = name;
            this.schema = schema;
            this.required = required;
        }
    }
}
