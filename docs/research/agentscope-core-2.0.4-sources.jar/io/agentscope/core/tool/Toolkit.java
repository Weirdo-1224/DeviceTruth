/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.core.tool;

import io.agentscope.core.agent.Agent;
import io.agentscope.core.agent.RuntimeContext;
import io.agentscope.core.message.ToolResultBlock;
import io.agentscope.core.message.ToolUseBlock;
import io.agentscope.core.model.ExecutionConfig;
import io.agentscope.core.model.ToolSchema;
import io.agentscope.core.tool.mcp.McpClientWrapper;
import io.agentscope.core.tool.subagent.SubAgentConfig;
import io.agentscope.core.tool.subagent.SubAgentProvider;
import io.agentscope.core.tool.subagent.SubAgentTool;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

/**
 * Toolkit manages the registration, retrieval, and execution of agent tools.
 * This class acts as a facade, delegating specific responsibilities to specialized managers:
 *
 * <p><b>Managers:</b>
 * <ul>
 *   <li>ToolRegistry: Tool registration and lookup</li>
 *   <li>ToolGroupManager: Tool group CRUD operations and active group management</li>
 *   <li>ToolSchemaProvider: Tool schema generation with group filtering</li>
 *   <li>McpClientManager: MCP client lifecycle and tool registration</li>
 *   <li>MetaToolFactory: Creates meta tools for dynamic group control</li>
 * </ul>
 *
 * <p><b>Core Components:</b>
 * <ul>
 *   <li>ToolSchemaGenerator: Generates JSON schemas for tool parameters</li>
 *   <li>ToolMethodInvoker: Handles method invocation and parameter conversion</li>
 *   <li>ToolResultConverter: Converts method results to ToolResultBlock</li>
 *   <li>ToolExecutor: Handles parallel/sequential tool execution with validation</li>
 * </ul>
 *
 * <p><b>Features:</b>
 * <ul>
 *   <li>Tool group management for dynamic tool activation</li>
 *   <li>State management via StateModule interface (activeGroups persistence)</li>
 *   <li>Meta tool for runtime tool group control (reset_equipped_tools)</li>
 *   <li>MCP (Model Context Protocol) client support for external tool providers</li>
 * </ul>
 */
public class Toolkit {

    private static final Logger logger = LoggerFactory.getLogger(Toolkit.class);

    private final ToolGroupManager groupManager = new ToolGroupManager();
    private final ToolRegistry toolRegistry = new ToolRegistry();
    private final ToolSchemaProvider schemaProvider;
    private final MetaToolFactory metaToolFactory;
    private AgentTool registeredMetaTool;
    private final McpClientManager mcpClientManager;
    private final ToolSchemaGenerator schemaGenerator = new ToolSchemaGenerator();
    private final ToolMethodInvoker methodInvoker;
    private final ToolkitConfig config;
    private final ToolExecutor executor;

    /**
     * Create a Toolkit with default configuration (parallel execution using Reactor).
     */
    public Toolkit() {
        this(ToolkitConfig.defaultConfig());
    }

    /**
     * Create a Toolkit with custom configuration.
     *
     * @param config Toolkit configuration (if null, uses defaultConfig())
     */
    public Toolkit(ToolkitConfig config) {
        this.config = config != null ? config : ToolkitConfig.defaultConfig();
        this.methodInvoker = new ToolMethodInvoker(new DefaultToolResultConverter());
        this.schemaProvider = new ToolSchemaProvider(toolRegistry, groupManager);
        this.metaToolFactory = new MetaToolFactory(groupManager, toolRegistry);
        this.mcpClientManager =
                new McpClientManager(
                        toolRegistry,
                        groupManager,
                        (tool, groupName, mcpClientName, presetParameters) ->
                                registerAgentTool(
                                        tool, groupName, null, mcpClientName, presetParameters));

        // Create executor based on configuration
        if (config != null && config.hasCustomExecutor()) {
            this.executor =
                    new ToolExecutor(
                            this,
                            toolRegistry,
                            groupManager,
                            this.config,
                            config.getExecutorService());
        } else {
            this.executor = new ToolExecutor(this, toolRegistry, groupManager, this.config);
        }
    }

    /**
     * Create a fluent builder for registering tools with optional configuration.
     *
     * <p>Example usage:
     * <pre>{@code
     * // Register tool object
     * toolkit.registration()
     *     .tool(myToolObject)
     *     .group("myGroup")
     *     .presetParameters(Map.of(
     *         "myTool", Map.of("apiKey", "secret")
     *     ))
     *     .apply();
     *
     * // Register MCP client
     * toolkit.registration()
     *     .mcpClient(mcpClientWrapper)
     *     .enableTools(List.of("tool1", "tool2"))
     *     .group("mcpGroup")
     *     .presetParameters(Map.of(
     *         "tool1", Map.of("apiKey", "key1")
     *     ))
     *     .apply();
     * }</pre>
     *
     * @return A new ToolRegistration builder
     */
    public ToolRegistration registration() {
        return new ToolRegistration(this);
    }

    /**
     * Register a tool object by scanning for methods annotated with @Tool.
     * @param toolObject the object containing tool methods
     */
    public void registerTool(Object toolObject) {
        registerTool(toolObject, null, null, null);
    }

    /**
     * Internal method: Register a tool object with group, extended model, and preset parameters.
     */
    private void registerTool(
            Object toolObject,
            String groupName,
            ExtendedModel extendedModel,
            Map<String, Map<String, Object>> presetParameters) {
        if (toolObject == null) {
            throw new IllegalArgumentException("Tool object cannot be null");
        }

        // Check if the object is an AgentTool instance
        if (toolObject instanceof AgentTool) {
            AgentTool agentTool = (AgentTool) toolObject;
            String toolName = agentTool.getName();
            Map<String, Object> toolPresets =
                    (presetParameters != null && presetParameters.containsKey(toolName))
                            ? presetParameters.get(toolName)
                            : null;
            registerAgentTool(agentTool, groupName, extendedModel, null, toolPresets);
            return;
        }

        Class<?> clazz = toolObject.getClass();
        Method[] methods = clazz.getDeclaredMethods();

        for (Method method : methods) {
            if (method.isAnnotationPresent(Tool.class)) {
                Tool toolAnnotation = method.getAnnotation(Tool.class);
                String toolName =
                        toolAnnotation.name().isEmpty() ? method.getName() : toolAnnotation.name();
                Map<String, Object> toolPresets =
                        (presetParameters != null && presetParameters.containsKey(toolName))
                                ? presetParameters.get(toolName)
                                : null;
                registerToolMethod(toolObject, method, groupName, extendedModel, toolPresets);
            }
        }
    }

    /**
     * Register an AgentTool instance directly.
     * @param tool the AgentTool to register
     */
    public void registerAgentTool(AgentTool tool) {
        registerAgentTool(tool, null, null, null, null);
    }

    /**
     * Internal method to register AgentTool with full metadata including preset parameters.
     */
    private void registerAgentTool(
            AgentTool tool,
            String groupName,
            ExtendedModel extendedModel,
            String mcpClientName,
            Map<String, Object> presetParameters) {
        if (tool == null) {
            throw new IllegalArgumentException("AgentTool cannot be null");
        }

        String toolName = tool.getName();

        // Validate group exists if specified
        if (groupName != null) {
            groupManager.validateGroupExists(groupName);
        }

        // Create registered wrapper with preset parameters
        RegisteredToolFunction registered =
                new RegisteredToolFunction(tool, extendedModel, mcpClientName, presetParameters);

        // Register in toolRegistry
        toolRegistry.registerTool(toolName, tool, registered);

        // Add to group if specified
        if (groupName != null) {
            groupManager.addToolToGroup(groupName, toolName);
        }

        logger.info(
                "Registered tool '{}' in group '{}'",
                toolName,
                groupName != null ? groupName : "ungrouped");
    }

    /**
     * Retrieves a tool by its name.
     *
     * @param name The name of the tool to retrieve
     * @return The AgentTool instance, or null if not found
     */
    public AgentTool getTool(String name) {
        return toolRegistry.getTool(name);
    }

    /**
     * Resolve a tool by name, composing a per-call {@link ToolRequestConfig} with the shared
     * registry (never mutating either). External tools from the request config take priority over
     * the backend registry; in {@link ToolMergeMode#EXTERNAL_ONLY} the
     * backend is hidden entirely.
     *
     * @param name tool name
     * @param requestConfig per-call request config (may be {@code null} → {@link
     *     ToolRequestConfig#NONE})
     * @return the resolved tool, or {@code null} when not found or hidden
     */
    public AgentTool getTool(String name, ToolRequestConfig requestConfig) {
        return (requestConfig != null ? requestConfig : ToolRequestConfig.NONE)
                .resolveTool(name, this.toolRegistry);
    }

    /**
     * Gets the names of all registered tools.
     *
     * @return A set of all tool names (never null, may be empty)
     */
    public Set<String> getToolNames() {
        return toolRegistry.getToolNames();
    }

    // ==================== External Tool Support ====================

    /**
     * Register an external tool using only its schema definition.
     *
     * <p>External tools are tools that will be executed outside the framework. When a model
     * returns a call to an external tool, the framework will not execute it but instead
     * return the tool call to the user via a message with
     * {@link io.agentscope.core.message.GenerateReason#TOOL_SUSPENDED}.
     *
     * <p>Example usage:
     * <pre>{@code
     * ToolSchema schema = ToolSchema.builder()
     *     .name("query_database")
     *     .description("Query external database")
     *     .parameters(Map.of(
     *         "type", "object",
     *         "properties", Map.of("sql", Map.of("type", "string")),
     *         "required", List.of("sql")
     *     ))
     *     .build();
     *
     * toolkit.registerSchema(schema);
     * }</pre>
     *
     * @param schema The tool schema containing name, description, and parameters
     * @throws NullPointerException if schema is null
     * @see SchemaOnlyTool
     * @see #isExternalTool(String)
     */
    public void registerSchema(ToolSchema schema) {
        registerAgentTool(new SchemaOnlyTool(schema));
    }

    /**
     * Register multiple external tools using their schema definitions.
     *
     * @param schemas List of tool schemas to register
     * @throws NullPointerException if schemas is null
     * @see #registerSchema(ToolSchema)
     */
    public void registerSchemas(List<ToolSchema> schemas) {
        if (schemas != null) {
            schemas.forEach(this::registerSchema);
        }
    }

    /**
     * Check if a tool is an external tool (requires execution outside the framework).
     *
     * <p>A tool is considered external when it extends {@link ToolBase} and reports
     * {@code isExternalTool() == true} — for example {@link SchemaOnlyTool}, or any
     * {@code @Tool(externalTool=true)} method. When this returns true, the framework will skip
     * execution and surface the tool call to the user via {@code TOOL_SUSPENDED}.
     *
     * @param toolName The name of the tool to check
     * @return true if the tool is an external tool, false otherwise
     */
    public boolean isExternalTool(String toolName) {
        AgentTool tool = getTool(toolName);
        return tool instanceof ToolBase tb && tb.isExternalTool();
    }

    /**
     * Check whether {@code toolName} resolves to an external tool under a per-call {@link
     * ToolRequestConfig}. Resolves the tool via {@link #getTool(String, ToolRequestConfig)}, so
     * externally injected (schema-only) tools from the request config are recognised as external in
     * addition to backend-registered external tools. A {@code null} request config resolves against
     * the shared registry only (equivalent to {@link #isExternalTool(String)}).
     *
     * @param toolName The name of the tool to check
     * @param requestConfig per-call request config (may be {@code null} → shared registry only)
     * @return true if the resolved tool is an external tool, false otherwise
     */
    public boolean isExternalTool(String toolName, ToolRequestConfig requestConfig) {
        AgentTool tool = getTool(toolName, requestConfig);
        return tool instanceof ToolBase tb && tb.isExternalTool();
    }

    /**
     * Get tool schemas as ToolSchema objects.
     * Updated to respect active tool groups.
     *
     * <p><b>Legacy single-session API:</b> resolves against the shared activation flags. Per-call
     * paths use {@link #getToolSchemas(java.util.Collection, ToolRequestConfig)}.
     *
     * @return List of ToolSchema objects
     */
    public List<ToolSchema> getToolSchemas() {
        return schemaProvider.getToolSchemas();
    }

    /**
     * Get tool schemas filtered by an explicitly supplied set of active group names, independent
     * of this toolkit's shared per-group activation flags.
     *
     * <p>Per-call / stateless variant of {@link #getToolSchemas()}: callers that track activated
     * groups in their own per-{@code (userId, sessionId)} state (e.g. {@code ReActAgent}) use this
     * so the model's tool surface is resolved from the call's own slot rather than from the shared,
     * concurrently-mutated toolkit activation flags.
     *
     * @param activeGroups the group names to treat as active for this resolution
     * @return List of ToolSchema objects visible for the supplied groups (plus all ungrouped tools)
     */
    public List<ToolSchema> getToolSchemas(Collection<String> activeGroups) {
        return schemaProvider.getToolSchemas(activeGroups);
    }

    /**
     * Stateless compose: the backend registry filtered by {@code activeGroups}, then a per-call
     * {@link ToolRequestConfig} applied without mutating the shared registry or group manager.
     *
     * <ol>
     *   <li>In {@link ToolMergeMode#EXTERNAL_ONLY} the backend is hidden
     *       entirely without deleting any registrations.
     *   <li>Backend schemas whose names collide with an external tool are dropped (external tools
     *       override the backend).
     *   <li>External tool schemas are appended.
     * </ol>
     *
     * @param activeGroups the group names treated as active for this resolution
     * @param requestConfig per-call request config (may be {@code null} → {@link
     *     ToolRequestConfig#NONE})
     * @return the composed tool schemas
     */
    public List<ToolSchema> getToolSchemas(
            Collection<String> activeGroups, ToolRequestConfig requestConfig) {
        if (requestConfig == null) {
            requestConfig = ToolRequestConfig.NONE;
        }
        boolean hideBackend = requestConfig.hidesBackend();

        List<ToolSchema> schemas = new ArrayList<>();
        if (!hideBackend) {
            for (ToolSchema schema : schemaProvider.getToolSchemas(activeGroups)) {
                if (!requestConfig.overrides(schema.getName())) {
                    schemas.add(schema);
                }
            }
        }
        for (SchemaOnlyTool tool : requestConfig.externalTools().values()) {
            schemas.add(
                    ToolSchema.builder()
                            .name(tool.getName())
                            .description(tool.getDescription())
                            .parameters(tool.getParameters())
                            .strict(tool.getStrict())
                            .outputSchema(tool.getOutputSchema())
                            .build());
        }
        return schemas;
    }

    /**
     * Register a tool method with group, extended model, and preset parameters.
     *
     * <p>Builds a {@link ReflectiveFunctionTool} (a {@link ToolBase} subclass) so the registered
     * tool participates in permission evaluation, the {@link ToolExecutor} safe-flag machinery,
     * and the agent's pending-confirmation flow alongside MCP and built-in tools.
     */
    private void registerToolMethod(
            Object toolObject,
            Method method,
            String groupName,
            ExtendedModel extendedModel,
            Map<String, Object> presetParameters) {
        Tool toolAnnotation = method.getAnnotation(Tool.class);

        String toolName =
                !toolAnnotation.name().isEmpty() ? toolAnnotation.name() : method.getName();
        String description =
                !toolAnnotation.description().isEmpty()
                        ? toolAnnotation.description()
                        : "Tool: " + toolName;

        // Parse custom converter from annotation
        ToolResultConverter customConverter = parseConverterFromAnnotation(toolAnnotation);

        Set<String> presetParamNames =
                presetParameters != null ? presetParameters.keySet() : Collections.emptySet();

        AgentTool tool =
                ReflectiveFunctionTool.create(
                        toolObject,
                        method,
                        toolAnnotation,
                        toolName,
                        description,
                        schemaGenerator,
                        methodInvoker,
                        customConverter,
                        presetParamNames);

        registerAgentTool(tool, groupName, extendedModel, null, presetParameters);
    }

    /**
     * Parses and instantiates converter from @Tool annotation.
     *
     * @param toolAnnotation The Tool annotation
     * @return A ToolResultConverter instance, or null to use default
     */
    private ToolResultConverter parseConverterFromAnnotation(Tool toolAnnotation) {
        if (toolAnnotation == null) {
            return null;
        }

        try {
            Class<? extends ToolResultConverter> converterClass = toolAnnotation.converter();
            // If explicitly set to DefaultToolResultConverter, return null to use the default
            if (converterClass == DefaultToolResultConverter.class) {
                return null;
            }
            return instantiateConverter(converterClass);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to create converter from @Tool annotation", e);
        }
    }

    /**
     * Instantiates a converter class with proper constructor resolution. Tries: 1) no-arg
     * constructor, 2) constructor with ObjectMapper
     *
     * @param clazz The converter class to instantiate
     * @return A new converter instance
     */
    private ToolResultConverter instantiateConverter(Class<? extends ToolResultConverter> clazz)
            throws Exception {
        // Try no-arg constructor first
        try {
            return clazz.getDeclaredConstructor().newInstance();
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException(
                    "Converter " + clazz.getName() + " must have either a no-arg constructor");
        }
    }

    /**
     * Set the chunk callback for streaming tool responses.
     *
     * <p>This callback is preserved when the toolkit is deep-copied and will be invoked whenever
     * tools emit progress updates via ToolEmitter. When the toolkit is used by ReActAgent, the
     * user callback is invoked in addition to the framework's internal chunk callback.
     *
     * @param callback Callback to invoke when tools emit chunks via ToolEmitter
     */
    public void setChunkCallback(BiConsumer<ToolUseBlock, ToolResultBlock> callback) {
        executor.setChunkCallback(callback);
    }

    /**
     * Execute a tool with the given parameters.
     *
     * <p>Example usage:
     *
     * <pre>{@code
     * // Simple call
     * ToolCallParam param = ToolCallParam.builder()
     *     .toolUseBlock(toolCall)
     *     .build();
     * toolkit.callTool(param);
     *
     * // With agent and context
     * ToolCallParam param = ToolCallParam.builder()
     *     .toolUseBlock(toolCall)
     *     .agent(agent)
     *     .context(context)
     *     .build();
     * toolkit.callTool(param);
     * }</pre>
     *
     * @param param Tool call parameters containing execution information
     * @return Mono containing execution result
     */
    public Mono<ToolResultBlock> callTool(ToolCallParam param) {
        return executor.execute(param);
    }

    /**
     * Execute multiple tools asynchronously with agent-level context (internal use by
     * ReActAgent).
     *
     * <p><b>Internal API - Not recommended for external use.</b> This method is primarily
     * intended for use by {@link io.agentscope.core.ReActAgent} and other framework components.
     *
     * <p>This method handles parallel/sequential execution based on toolkit configuration and
     * applies execution config (timeout, retry) from multiple levels. The agent context is
     * merged with toolkit default context during tool execution.
     *
     * @param toolCalls List of tool calls to execute
     * @param agentExecutionConfig Execution config from agent level (can be null)
     * @param agent The agent making the calls (may be null)
     * @param agentRuntimeContext The agent-level runtime context (may be null)
     * @return Mono containing list of tool responses
     */
    public Mono<List<ToolResultBlock>> callTools(
            List<ToolUseBlock> toolCalls,
            ExecutionConfig agentExecutionConfig,
            Agent agent,
            RuntimeContext agentRuntimeContext) {
        return callTools(toolCalls, agentExecutionConfig, agent, agentRuntimeContext, null);
    }

    /**
     * Execute multiple tools with request configuration from the runtime context and a per-call chunk callback.
     *
     * @param internalChunkCallback per-call internal chunk callback (may be {@code null})
     */
    public Mono<List<ToolResultBlock>> callTools(
            List<ToolUseBlock> toolCalls,
            ExecutionConfig agentExecutionConfig,
            Agent agent,
            RuntimeContext agentRuntimeContext,
            BiConsumer<ToolUseBlock, ToolResultBlock> internalChunkCallback) {
        return callTools(
                toolCalls,
                agentExecutionConfig,
                agent,
                agentRuntimeContext,
                agentRuntimeContext == null
                        ? ToolRequestConfig.NONE
                        : agentRuntimeContext.getToolRequestConfig(),
                internalChunkCallback);
    }

    /**
     * Execute multiple tools with a per-call {@link ToolRequestConfig} and internal chunk
     * callback, both threaded down to every single-tool execution.
     */
    public Mono<List<ToolResultBlock>> callTools(
            List<ToolUseBlock> toolCalls,
            ExecutionConfig agentExecutionConfig,
            Agent agent,
            RuntimeContext agentRuntimeContext,
            ToolRequestConfig requestConfig,
            BiConsumer<ToolUseBlock, ToolResultBlock> internalChunkCallback) {
        // Merge execution configs: agent-level > toolkit-level > system default
        ExecutionConfig effectiveConfig =
                ExecutionConfig.mergeConfigs(
                        agentExecutionConfig,
                        ExecutionConfig.mergeConfigs(
                                config.getExecutionConfig(), ExecutionConfig.TOOL_DEFAULTS));

        return executor.executeAll(
                toolCalls,
                config.isParallel(),
                effectiveConfig,
                agent,
                agentRuntimeContext,
                requestConfig != null
                        ? requestConfig
                        : agentRuntimeContext == null
                                ? ToolRequestConfig.NONE
                                : agentRuntimeContext.getToolRequestConfig(),
                internalChunkCallback);
    }

    // ==================== MCP Client Registration (Delegated) ====================

    /**
     * Registers an MCP client and all its tools.
     *
     * <p>For more complex registration scenarios (filtering, groups, preset parameters),
     * use the builder API: {@code toolkit.registration().mcpClient(...).apply()}
     *
     * @param mcpClientWrapper the MCP client wrapper
     * @return Mono that completes when registration is finished
     */
    public Mono<Void> registerMcpClient(McpClientWrapper mcpClientWrapper) {
        return mcpClientManager.registerMcpClient(mcpClientWrapper);
    }

    /**
     * Removes an MCP client and all its tools.
     *
     * @param mcpClientName the name of the MCP client to remove
     * @return Mono that completes when removal is finished
     */
    public Mono<Void> removeMcpClient(String mcpClientName) {
        return mcpClientManager.removeMcpClient(mcpClientName);
    }

    /** Releases clients registered by this toolkit. Copies do not own the source's clients. */
    public void closeMcpClients() {
        for (String name : mcpClientManager.getMcpClientNames()) {
            try {
                removeMcpClient(name).block();
            } catch (RuntimeException e) {
                logger.warn(
                        "MCP client '{}' cleanup failed ({})", name, e.getClass().getSimpleName());
            }
        }
    }

    // ==================== Tool Group Management (Delegated) ====================

    /**
     * Create a new tool group with specified activation status and default META scope.
     *
     * @param groupName Name of the tool group
     * @param description Description of the tool group
     * @param active Whether the group should be active by default
     * @throws IllegalArgumentException if group already exists
     */
    public void createToolGroup(String groupName, String description, boolean active) {
        groupManager.createToolGroup(groupName, description, active);
    }

    /**
     * Create a new tool group with specified activation status and scope.
     *
     * @param groupName Name of the tool group
     * @param description Description of the tool group
     * @param active Whether the group should be active by default
     * @param scope Whether the group is managed by the meta tool ({@link ToolGroupScope#META})
     *              or by developer code ({@link ToolGroupScope#EXTERNAL})
     * @throws IllegalArgumentException if group already exists
     */
    public void createToolGroup(
            String groupName, String description, boolean active, ToolGroupScope scope) {
        groupManager.createToolGroup(groupName, description, active, scope);
    }

    /**
     * Create a new tool group (active by default, META scope).
     *
     * @param groupName Name of the tool group
     * @param description Description of the tool group
     * @throws IllegalArgumentException if group already exists
     */
    public void createToolGroup(String groupName, String description) {
        groupManager.createToolGroup(groupName, description);
    }

    /**
     * Create a {@link SkillToolGroup} bound to a specific skill.
     *
     * <p>The group defaults to {@link ToolGroupScope#META} scope so the agent can manage it
     * via {@code reset_equipped_tools}. The description shown to the model will include a
     * reminder that this group must be activated when the bound skill is in use.
     *
     * @param groupName Name of the tool group
     * @param description Description of the tool group
     * @param active Whether the group should be active by default
     * @param activateOnSkill The skill name that this group is bound to
     * @throws IllegalArgumentException if group already exists
     */
    public void createSkillToolGroup(
            String groupName, String description, boolean active, String activateOnSkill) {
        groupManager.createSkillToolGroup(groupName, description, active, activateOnSkill);
    }

    /**
     * Find all {@link SkillToolGroup} instances whose {@code activateOnSkill} matches the given
     * skill name.
     *
     * @param skillName The skill name to match against
     * @return List of matching group names (never null, may be empty)
     */
    public List<String> findSkillToolGroupsByActivateOnSkill(String skillName) {
        return groupManager.findSkillToolGroupsByActivateOnSkill(skillName);
    }

    /**
     * Register a pre-built {@link ToolGroup} instance (including subclasses).
     *
     * <p>Use this method when you need full control over the ToolGroup construction,
     * e.g., for custom subclasses like {@link SkillToolGroup}.
     *
     * @param group The tool group to register
     * @throws IllegalArgumentException if a group with the same name already exists
     */
    public void registerToolGroup(ToolGroup group) {
        groupManager.registerToolGroup(group);
    }

    /**
     * Add an already-registered tool to an existing tool group.
     *
     * <p>A tool may belong to multiple groups. Adding the same tool to the same group more than
     * once has no additional effect.
     *
     * @param groupName Name of the existing tool group
     * @param toolName Name of the registered tool
     * @throws IllegalArgumentException if the group or tool doesn't exist
     */
    public void addToolToGroup(String groupName, String toolName) {
        groupManager.validateGroupExists(groupName);
        if (toolRegistry.getTool(toolName) == null) {
            throw new IllegalArgumentException("Tool not found: " + toolName);
        }
        groupManager.addToolToGroup(groupName, toolName);
    }

    /**
     * Update the activation status of tool groups.
     *
     * <p>When {@code allowToolDeletion} is disabled and {@code active} is false, the deactivation
     * will be ignored and a warning will be logged.
     *
     * <p><b>Legacy single-session API:</b> mutates the shared activation flags. Per-call paths do
     * not use this.
     *
     * @param groupNames List of tool group names to update
     * @param active Whether to activate (true) or deactivate (false) the groups
     * @throws IllegalArgumentException if any group doesn't exist
     */
    public void updateToolGroups(List<String> groupNames, boolean active) {
        if (!active && !config.isAllowToolDeletion()) {
            logger.warn(
                    "Tool deletion is disabled - ignoring deactivation of tool groups: {}",
                    groupNames);
            return;
        }
        groupManager.updateToolGroups(groupNames, active);
    }

    /**
     * Remove a tool by name from the toolkit.
     *
     * @param toolName Name of the tool to remove
     */
    public void removeTool(String toolName) {
        if (!config.isAllowToolDeletion()) {
            logger.warn("Tool deletion is disabled - ignoring removal of tool: {}", toolName);
            return;
        }
        toolRegistry.removeTool(toolName);
    }

    /**
     * Atomically remove a tool only if the registered instance is the expected one.
     *
     * @param toolName Name of the tool to remove
     * @param expected The expected AgentTool instance (identity comparison)
     * @return true if the tool was removed, false if it was already replaced or absent
     */
    public boolean removeToolIfSame(String toolName, AgentTool expected) {
        if (!config.isAllowToolDeletion()) {
            logger.warn("Tool deletion is disabled - ignoring removal of tool: {}", toolName);
            return false;
        }
        return toolRegistry.removeToolIfSame(toolName, expected);
    }

    /**
     * Remove tool groups and all tools within them.
     *
     * <p>When {@code allowToolDeletion} is disabled, the removal will be ignored and a warning
     * will be logged.
     *
     * @param groupNames List of tool group names to remove
     */
    public void removeToolGroups(List<String> groupNames) {
        if (!config.isAllowToolDeletion()) {
            logger.warn(
                    "Tool deletion is disabled - ignoring removal of tool groups: {}", groupNames);
            return;
        }
        Set<String> toolsToRemove = groupManager.removeToolGroups(groupNames);
        // Remove tools from registry
        toolRegistry.removeTools(toolsToRemove);
    }

    /**
     * Get active tool group names.
     *
     * <p>Returns a list of all currently active tool group names. Only tools belonging to active
     * groups can be called by agents. This method is useful for debugging tool availability
     * and verifying group activation state.
     *
     * <p><b>Legacy single-session API:</b> reads the shared, build-time activation flags. Per-call
     * paths resolve activation from {@code AgentState#getToolContext()} instead.
     *
     * @return List of active group names, never null but may be empty
     */
    public List<String> getActiveGroups() {
        return groupManager.getActiveGroups();
    }

    /**
     * Set the active tool groups.
     *
     * <p>This method is typically called by ReActAgent when restoring state from a session.
     *
     * <p><b>Legacy single-session API:</b> mutates the shared activation flags. Per-call paths
     * never call this (activation lives on {@code AgentState#getToolContext()}).
     *
     * @param groups List of group names to set as active
     */
    public void setActiveGroups(List<String> groups) {
        groupManager.setActiveGroups(groups);
    }

    /**
     * Get a tool group by name.
     *
     * @param groupName Name of the tool group
     * @return ToolGroup or null if not found
     */
    public ToolGroup getToolGroup(String groupName) {
        return groupManager.getToolGroup(groupName);
    }

    // ==================== Meta Tool Registration ====================

    /**
     * Register the meta tool that allows agents to dynamically manage tool groups.
     *
     * This creates a tool that wraps the toolkit's resetEquippedTools method,
     * allowing the agent to activate tool groups during execution.
     */
    public void registerMetaTool() {
        AgentTool metaTool = metaToolFactory.createResetEquippedToolsAgentTool();
        registeredMetaTool = metaTool;

        // Register without group (meta tool is always available)
        registerAgentTool(metaTool, null, null, null, null);

        logger.info("Registered meta tool: reset_equipped_tools");
    }

    /**
     * Update preset parameters for a registered tool at runtime.
     *
     * <p>This method allows dynamic modification of preset parameters without re-registering the
     * tool. This is useful for updating session-specific context (like session IDs or timestamps)
     * or refreshing credentials.
     *
     * @param toolName The name of the tool to update
     * @param newPresetParameters The new preset parameters (null will be treated as empty map)
     * @throws IllegalArgumentException if the tool is not found
     */
    public void updateToolPresetParameters(
            String toolName, Map<String, Object> newPresetParameters) {
        RegisteredToolFunction registered = toolRegistry.getRegisteredTool(toolName);
        if (registered == null) {
            throw new IllegalArgumentException("Tool not found: " + toolName);
        }
        registered.updatePresetParameters(newPresetParameters);
        logger.debug("Updated preset parameters for tool '{}'", toolName);
    }

    // ==================== Build-time Isolation Copy ====================

    /**
     * Creates a build-time isolation copy of this toolkit.
     *
     * <p><b>Build-time only — do NOT use per-call.</b> User tools are shared by reference and must support concurrent use; the framework meta
     * tool is rebound to the copied registry. Tool groups and activation flags
     * are deep-copied so the copy has an isolated group manager. The user chunk callback is
     * preserved.
     *
     * <p>Per-call tool-surface variation is instead expressed via {@link ToolRequestConfig}
     * composition ({@link #getTool(String, ToolRequestConfig)} / {@link
     * #getToolSchemas(java.util.Collection, ToolRequestConfig)}), never by copying a toolkit. This
     * method exists for agent-construction isolation (e.g. the harness sub-agent factories), where
     * a fresh registry is needed to register workspace-bound tools without polluting the source.
     *
     * @return A new Toolkit instance whose registry shares the same tool instances
     */
    public Toolkit copy() {
        Toolkit copy = new Toolkit(this.config);

        // Share tool instances (stateless/thread-safe); copy registry metadata into the target.
        this.toolRegistry.copyTo(copy.toolRegistry);

        // Deep-copy tool groups and activation flags for isolated group state.
        this.groupManager.copyTo(copy.groupManager);

        // The framework meta tool captures its owner's group manager; bind it to the copy.
        if (registeredMetaTool != null
                && toolRegistry.getTool(registeredMetaTool.getName()) == registeredMetaTool) {
            copy.registerMetaTool();
            RegisteredToolFunction metadata =
                    toolRegistry.getRegisteredTool(registeredMetaTool.getName());
            if (metadata != null) {
                copy.updateToolPresetParameters(
                        registeredMetaTool.getName(), metadata.getPresetParameters());
            }
        }

        // Preserve user-defined chunk callbacks across build-time copies.
        copy.executor.setChunkCallback(this.executor.getChunkCallback());

        return copy;
    }

    // ==================== Fluent Registration ====================

    /**
     * Fluent builder for registering tools with optional configuration.
     *
     * <p>This builder provides a clear, type-safe way to register tools with various options
     * without method proliferation.
     */
    public static class ToolRegistration {
        private final Toolkit toolkit;
        private Object toolObject;
        private AgentTool agentTool;
        private McpClientWrapper mcpClientWrapper;
        private SubAgentProvider<?> subAgentProvider;
        private SubAgentConfig subAgentConfig;
        private String groupName;
        private Map<String, Map<String, Object>> presetParameters;
        private ExtendedModel extendedModel;
        private List<String> enableTools;
        private String mcpToolNamePrefix = "";
        private List<String> disableTools;
        private Boolean propagateMeta;
        private final Map<String, Boolean> toolPropagateMeta = new LinkedHashMap<>();

        private ToolRegistration(Toolkit toolkit) {
            this.toolkit = toolkit;
        }

        /**
         * Set the tool object to register (scans for @Tool methods).
         *
         * @param toolObject Object containing @Tool annotated methods
         * @return This builder for chaining
         */
        public ToolRegistration tool(Object toolObject) {
            this.toolObject = toolObject;
            return this;
        }

        /**
         * Set the AgentTool instance to register.
         *
         * @param agentTool The AgentTool instance
         * @return This builder for chaining
         */
        public ToolRegistration agentTool(AgentTool agentTool) {
            this.agentTool = agentTool;
            return this;
        }

        /**
         * Set the MCP client to register.
         *
         * @param mcpClientWrapper The MCP client wrapper
         * @return This builder for chaining
         */
        public ToolRegistration mcpClient(McpClientWrapper mcpClientWrapper) {
            this.mcpClientWrapper = mcpClientWrapper;
            return this;
        }

        /**
         * Register a sub-agent as a tool with default configuration.
         *
         * <p>The tool name and description are derived from the agent's properties. Uses a single
         * "task" string parameter by default.
         *
         * <p>Example:
         *
         * <pre>{@code
         * toolkit.registration()
         *     .subAgent(() -> ReActAgent.builder()
         *         .name("ResearchAgent")
         *         .model(model)
         *         .build())
         *     .apply();
         * }</pre>
         *
         * @param provider Factory for creating agent instances (called for each invocation)
         * @return This builder for chaining
         */
        public ToolRegistration subAgent(SubAgentProvider<?> provider) {
            return subAgent(provider, null);
        }

        /**
         * Register a sub-agent as a tool with custom configuration.
         *
         * <p>Sub-agents support multi-turn conversation with session-based state management. The
         * tool exposes two parameters: {@code message} (required) and {@code session_id} (optional,
         * for continuing existing conversations).
         *
         * <p>Example with custom tool name and description:
         *
         * <pre>{@code
         * toolkit.registration()
         *     .subAgent(
         *         () -> ReActAgent.builder().name("Expert").model(model).build(),
         *         SubAgentConfig.builder()
         *             .toolName("ask_expert")
         *             .description("Ask the domain expert a question")
         *             .build())
         *     .apply();
         * }</pre>
         *
         * <p>Example with persistent session for cross-process conversations:
         *
         * <pre>{@code
         * toolkit.registration()
         *     .subAgent(
         *         () -> ReActAgent.builder().name("Assistant").model(model).build(),
         *         SubAgentConfig.builder()
         *             .stateStore(new JsonFileAgentStateStore(Path.of("sessions")))
         *             .forwardEvents(true)
         *             .build())
         *     .apply();
         * }</pre>
         *
         * @param provider Factory for creating agent instances (called for each session)
         * @param config Configuration for the sub-agent tool, or null to use defaults (tool name
         *     derived from agent name, InMemoryAgentStateStore for state, events forwarded)
         * @return This builder for chaining
         * @see SubAgentConfig
         * @see SubAgentConfig#defaults()
         */
        public ToolRegistration subAgent(SubAgentProvider<?> provider, SubAgentConfig config) {
            this.subAgentProvider = provider;
            this.subAgentConfig = config;
            return this;
        }

        /** Optional namespace for model-facing MCP tool names; wire names remain unchanged. */
        public ToolRegistration mcpToolNamePrefix(String prefix) {
            this.mcpToolNamePrefix = java.util.Objects.requireNonNull(prefix);
            return this;
        }

        /** Selects remote tool names; an absent or empty list enables all tools. */
        public ToolRegistration enableTools(List<String> enableTools) {
            this.enableTools = enableTools;
            return this;
        }

        /**
         * Set the list of tools to disable from the MCP client.
         *
         * <p>Only applicable when using mcpClient().
         *
         * @param disableTools List of tool names to disable
         * @return This builder for chaining
         */
        public ToolRegistration disableTools(List<String> disableTools) {
            this.disableTools = disableTools;
            return this;
        }

        /**
         * Controls whether request metadata is propagated to the MCP server registered through
         * this builder.
         *
         * <p>By default, entries registered under {@link io.agentscope.core.tool.mcp.McpMeta} in
         * the runtime context plus the framework tool-call id are sent as the {@code meta} field
         * of every tool call request. For MCP servers that are not fully trusted (e.g. external
         * third-party services), set this to {@code false} so no metadata leaves the process.
         *
         * <p>When unset, no per-tool restriction is recorded (the tool flag stays {@code true})
         * and the effective decision falls back to the connection-level switch on the MCP client
         * wrapper, which is read live on every call.
         *
         * <p>Only applicable when using mcpClient().
         *
         * @param propagateMeta true to propagate metadata, false to omit the {@code meta} field
         *     entirely from tool call requests
         * @return This builder for chaining
         */
        public ToolRegistration propagateMeta(boolean propagateMeta) {
            this.propagateMeta = propagateMeta;
            return this;
        }

        /**
         * Controls request metadata propagation for a single MCP tool of this client.
         *
         * <p>Per-tool entries win over the client-wide default set via
         * {@link #propagateMeta(boolean)}, and both are further ANDed with the connection-level
         * switch on the MCP client wrapper at call time. This mirrors the
         * {@code enableTools}/{@code disableTools} shape: use it to keep one trusted tool
         * receiving its metadata (e.g. a callback URL) while the rest of an untrusted server is
         * silenced, or vice versa.
         *
         * <p>The tool name is the remote MCP tool name as exposed by the server (before any
         * {@code mcpToolNamePrefix}). Repeat calls for different tools accumulate; a repeated
         * call for the same tool overwrites the previous value. An entry whose name does not
         * match a tool that is actually registered from this client (e.g. a typo or a name
         * filtered out by {@code enableTools}/{@code disableTools}) fails the registration
         * with an {@link IllegalArgumentException}, so a silencing override is never lost
         * silently.
         *
         * <p>Only applicable when using mcpClient().
         *
         * @param toolName the remote MCP tool name
         * @param propagateMeta true to allow metadata propagation for this tool, false to omit
         *     the {@code meta} field from this tool's requests
         * @return This builder for chaining
         * @throws IllegalArgumentException if {@code toolName} is {@code null} or blank
         */
        public ToolRegistration propagateMeta(String toolName, boolean propagateMeta) {
            if (toolName == null || toolName.isBlank()) {
                throw new IllegalArgumentException("MCP tool name cannot be null or blank");
            }
            this.toolPropagateMeta.put(toolName, propagateMeta);
            return this;
        }

        /**
         * Set the tool group name.
         *
         * @param groupName The group name (null for ungrouped)
         * @return This builder for chaining
         */
        public ToolRegistration group(String groupName) {
            this.groupName = groupName;
            return this;
        }

        /**
         * Set preset parameters that will be automatically injected during tool execution.
         *
         * <p>These parameters are not exposed in the JSON schema.
         *
         * <p>The map should have tool names as keys and parameter maps as values:
         * <pre>{@code
         * Map.of(
         *     "toolName1", Map.of("param1", "value1", "param2", "value2"),
         *     "toolName2", Map.of("param1", "value3")
         * )
         * }</pre>
         *
         * @param presetParameters Map from tool name to its preset parameters
         * @return This builder for chaining
         */
        public ToolRegistration presetParameters(
                Map<String, Map<String, Object>> presetParameters) {
            this.presetParameters = presetParameters;
            return this;
        }

        /**
         * Set the extended model for dynamic schema extension.
         *
         * @param extendedModel The extended model
         * @return This builder for chaining
         */
        public ToolRegistration extendedModel(ExtendedModel extendedModel) {
            this.extendedModel = extendedModel;
            return this;
        }

        /**
         * Apply the registration with all configured options.
         *
         * @throws IllegalStateException if none of tool(), agentTool(), mcpClient() or subAgent() was set
         * @throws IllegalStateException if set multiple of: tool(), agentTool(), mcpClient(), or subAgent().
         */
        public void apply() {
            int toolCount = 0;
            if (toolObject != null) toolCount++;
            if (agentTool != null) toolCount++;
            if (mcpClientWrapper != null) toolCount++;
            if (subAgentProvider != null) toolCount++;

            if (toolCount == 0) {
                throw new IllegalStateException(
                        "Must call one of: tool(), agentTool(), mcpClient(), or subAgent() before"
                                + " apply()");
            }
            if (toolCount > 1) {
                throw new IllegalStateException(
                        "Cannot set multiple registration types. Use only one of: tool(),"
                                + " agentTool(), mcpClient(), or subAgent().");
            }

            if (toolObject != null) {
                toolkit.registerTool(toolObject, groupName, extendedModel, presetParameters);
            } else if (agentTool != null) {
                String toolName = agentTool.getName();
                Map<String, Object> toolPresets =
                        (presetParameters != null && presetParameters.containsKey(toolName))
                                ? presetParameters.get(toolName)
                                : null;
                toolkit.registerAgentTool(agentTool, groupName, extendedModel, null, toolPresets);
            } else if (mcpClientWrapper != null) {
                toolkit.mcpClientManager
                        .registerMcpClient(
                                mcpClientWrapper,
                                enableTools,
                                disableTools,
                                groupName,
                                presetParameters,
                                mcpToolNamePrefix,
                                propagateMeta,
                                toolPropagateMeta)
                        .block();
            } else if (subAgentProvider != null) {
                SubAgentTool subAgentTool = new SubAgentTool(subAgentProvider, subAgentConfig);
                toolkit.registerAgentTool(subAgentTool, groupName, extendedModel, null, null);
            }
        }
    }
}
