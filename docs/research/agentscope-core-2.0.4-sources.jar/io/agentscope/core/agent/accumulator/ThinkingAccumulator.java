/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.core.agent.accumulator;

import io.agentscope.core.message.ContentBlock;
import io.agentscope.core.message.ThinkingBlock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Thinking content accumulator for accumulating streaming thinking chunks.
 *
 * <p>This accumulator concatenates all thinking chunks in order to build the complete thinking
 * content.
 *
 * <p>List-valued metadata (e.g. reasoning details) is accumulated in stream order: entries from
 * each chunk are appended rather than replaced. Scalar metadata uses last-write-wins. List values
 * are always copied to prevent caller mutation from affecting accumulator state.
 * @hidden
 */
public class ThinkingAccumulator implements ContentAccumulator<ThinkingBlock> {

    private final StringBuilder accumulated = new StringBuilder();
    private final Map<String, Object> metadata = new HashMap<>();

    /**
     * @hidden
     */
    @Override
    public void add(ThinkingBlock block) {
        if (block != null && block.getThinking() != null) {
            accumulated.append(block.getThinking());
        }
        if (block != null && block.getMetadata() != null && !block.getMetadata().isEmpty()) {
            mergeMetadata(block.getMetadata());
        }
    }

    /**
     * @hidden
     */
    @Override
    public boolean hasContent() {
        return accumulated.length() > 0 || !metadata.isEmpty();
    }

    /**
     * @hidden
     */
    @Override
    public ContentBlock buildAggregated() {
        if (!hasContent()) {
            return null;
        }
        ThinkingBlock.Builder builder = ThinkingBlock.builder().thinking(accumulated.toString());
        if (!metadata.isEmpty()) {
            builder.metadata(new HashMap<>(metadata));
        }
        return builder.build();
    }

    /**
     * @hidden
     */
    @Override
    public void reset() {
        accumulated.setLength(0);
        metadata.clear();
    }

    /**
     * Merges incoming metadata into the accumulator's metadata map.
     *
     * <p>List values are accumulated in stream order (entries appended, not replaced). Scalar
     * values use last-write-wins. List values are always copied to prevent caller mutation.
     */
    private void mergeMetadata(Map<String, Object> incoming) {
        for (Map.Entry<String, Object> entry : incoming.entrySet()) {
            String key = entry.getKey();
            Object newValue = entry.getValue();
            Object existing = metadata.get(key);
            if (existing instanceof List<?> existingList && newValue instanceof List<?> newList) {
                // Both are lists: concatenate in stream order
                List<Object> combined = new ArrayList<>(existingList);
                combined.addAll(newList);
                metadata.put(key, combined);
            } else if (newValue instanceof List<?> newList) {
                // First list for this key: copy to prevent caller mutation
                metadata.put(key, new ArrayList<>(newList));
            } else {
                // Scalar value: last-write-wins
                metadata.put(key, newValue);
            }
        }
    }

    /**
     * Get the accumulated thinking content.
     *
     * @hidden
     * @return accumulated thinking as string
     */
    public String getAccumulated() {
        return accumulated.toString();
    }
}
