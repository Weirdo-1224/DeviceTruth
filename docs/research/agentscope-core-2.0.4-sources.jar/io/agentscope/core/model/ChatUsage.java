/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.core.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents token usage information for chat completion responses.
 *
 * <p>This immutable data class tracks the number of tokens used during a chat completion,
 * including input tokens (prompt), output tokens (generated response), input/output token
 * breakdowns, and execution time.
 */
public class ChatUsage {

    private final int inputTokens;
    private final int outputTokens;
    private final int cachedTokens;
    private final int cacheCreationTokens;
    private final int reasoningTokens;
    private final int toolUsePromptTokens;
    private final double time;

    /**
     * Creates a new ChatUsage instance without token breakdowns.
     *
     * <p>This constructor is retained for backward compatibility. All token breakdowns default to
     * {@code 0}.
     *
     * @param inputTokens the number of tokens used for the input/prompt
     * @param outputTokens the number of tokens used for the output/generated response
     * @param time the execution time in seconds
     */
    public ChatUsage(int inputTokens, int outputTokens, double time) {
        this(inputTokens, outputTokens, 0, time);
    }

    /**
     * Creates a new ChatUsage instance.
     *
     * @param inputTokens the number of tokens used for the input/prompt
     * @param outputTokens the number of tokens used for the output/generated response
     * @param cachedTokens the number of input tokens served from the prompt cache (a subset of
     *     {@code inputTokens}); {@code 0} when the provider does not report cache information
     * @param time the execution time in seconds
     */
    public ChatUsage(
            @JsonProperty("inputTokens") int inputTokens,
            @JsonProperty("outputTokens") int outputTokens,
            @JsonProperty("cachedTokens") int cachedTokens,
            @JsonProperty("time") double time) {
        this(inputTokens, outputTokens, cachedTokens, 0, 0, 0, time);
    }

    /**
     * Creates a new ChatUsage instance with all token breakdowns.
     *
     * <p>This constructor is also used by Jackson to deserialize a {@code ChatUsage} object. When
     * a breakdown property is omitted from JSON, its primitive value defaults to {@code 0}.
     *
     * @param inputTokens the number of tokens used for the input/prompt
     * @param outputTokens the number of tokens used for the output/generated response
     * @param cachedTokens the number of input tokens served from the prompt cache (a subset of
     *     {@code inputTokens}); {@code 0} when the provider does not report cache information
     * @param cacheCreationTokens the number of input tokens used to create a prompt cache entry
     *     (a subset of {@code inputTokens}); {@code 0} when the provider does not report this
     *     information
     * @param reasoningTokens the number of output tokens used for model reasoning (a subset of
     *     {@code outputTokens}); {@code 0} when the provider does not report this information
     * @param toolUsePromptTokens the number of input tokens representing tool results returned to
     *     the model (a subset of {@code inputTokens}); {@code 0} when the provider does not report
     *     this information
     * @param time the execution time in seconds
     */
    @JsonCreator
    public ChatUsage(
            @JsonProperty("inputTokens") int inputTokens,
            @JsonProperty("outputTokens") int outputTokens,
            @JsonProperty("cachedTokens") int cachedTokens,
            @JsonProperty("cacheCreationTokens") int cacheCreationTokens,
            @JsonProperty("reasoningTokens") int reasoningTokens,
            @JsonProperty("toolUsePromptTokens") int toolUsePromptTokens,
            @JsonProperty("time") double time) {
        this.inputTokens = inputTokens;
        this.outputTokens = outputTokens;
        this.cachedTokens = cachedTokens;
        this.cacheCreationTokens = cacheCreationTokens;
        this.reasoningTokens = reasoningTokens;
        this.toolUsePromptTokens = toolUsePromptTokens;
        this.time = time;
    }

    /**
     * Gets the number of input tokens used.
     *
     * @return the number of tokens used for the input/prompt
     */
    public int getInputTokens() {
        return inputTokens;
    }

    /**
     * Gets the number of output tokens used.
     *
     * @return the number of tokens used for the output/generated response
     */
    public int getOutputTokens() {
        return outputTokens;
    }

    /**
     * Gets the number of input tokens served from the prompt cache.
     *
     * <p>Cached tokens are a subset of {@link #getInputTokens()} (i.e. {@code inputTokens =
     * non-cached prompt tokens + cachedTokens}), not an additional amount, and are typically billed
     * at a reduced rate. Returns {@code 0} when the provider does not report cache information.
     *
     * @return the number of cached input tokens
     */
    public int getCachedTokens() {
        return cachedTokens;
    }

    /**
     * Gets the number of input tokens used to create a prompt cache entry.
     *
     * <p>Cache creation tokens are a subset of {@link #getInputTokens()}, not an additional
     * amount, and may be billed separately from a cache hit. Returns {@code 0} when the provider
     * does not report this metric.
     *
     * @return the number of cache-creation input tokens
     */
    public int getCacheCreationTokens() {
        return cacheCreationTokens;
    }

    /**
     * Gets the number of output tokens used for model reasoning.
     *
     * <p>Reasoning tokens are a subset of {@link #getOutputTokens()}, not an additional amount.
     * Returns {@code 0} when the provider does not report this metric.
     *
     * @return the number of reasoning output tokens
     */
    public int getReasoningTokens() {
        return reasoningTokens;
    }

    /**
     * Gets the number of input tokens representing tool results returned to the model.
     *
     * <p>Tool-use prompt tokens are a subset of {@link #getInputTokens()}, not an additional
     * amount. Returns {@code 0} when the provider does not report this metric.
     *
     * @return the number of tool-result input tokens
     */
    public int getToolUsePromptTokens() {
        return toolUsePromptTokens;
    }

    /**
     * Gets the total number of tokens used.
     *
     * @return the sum of input and output tokens
     */
    public int getTotalTokens() {
        return inputTokens + outputTokens;
    }

    /**
     * Gets the execution time.
     *
     * @return the execution time in seconds
     */
    public double getTime() {
        return time;
    }

    /**
     * Creates a new builder for ChatUsage.
     *
     * @return a new Builder instance
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder for creating ChatUsage instances.
     */
    public static class Builder {
        private int inputTokens;
        private int outputTokens;
        private int cachedTokens;
        private int cacheCreationTokens;
        private int reasoningTokens;
        private int toolUsePromptTokens;
        private double time;

        /**
         * Sets the number of input tokens.
         *
         * @param inputTokens the number of tokens used for the input/prompt
         * @return this builder instance
         */
        public Builder inputTokens(int inputTokens) {
            this.inputTokens = inputTokens;
            return this;
        }

        /**
         * Sets the number of output tokens.
         *
         * @param outputTokens the number of tokens used for the output/generated response
         * @return this builder instance
         */
        public Builder outputTokens(int outputTokens) {
            this.outputTokens = outputTokens;
            return this;
        }

        /**
         * Sets the number of cached input tokens.
         *
         * @param cachedTokens the number of input tokens served from the prompt cache (a subset of
         *     {@code inputTokens})
         * @return this builder instance
         */
        public Builder cachedTokens(int cachedTokens) {
            this.cachedTokens = cachedTokens;
            return this;
        }

        /**
         * Sets the number of input tokens used to create a prompt cache entry.
         *
         * @param cacheCreationTokens the number of cache-creation input tokens (a subset of
         *     {@code inputTokens})
         * @return this builder instance
         */
        public Builder cacheCreationTokens(int cacheCreationTokens) {
            this.cacheCreationTokens = cacheCreationTokens;
            return this;
        }

        /**
         * Sets the number of output tokens used for model reasoning.
         *
         * @param reasoningTokens the number of output tokens used for reasoning (a subset of
         *     {@code outputTokens})
         * @return this builder instance
         */
        public Builder reasoningTokens(int reasoningTokens) {
            this.reasoningTokens = reasoningTokens;
            return this;
        }

        /**
         * Sets the number of input tokens representing tool results returned to the model.
         *
         * @param toolUsePromptTokens the number of tool-result input tokens (a subset of
         *     {@code inputTokens})
         * @return this builder instance
         */
        public Builder toolUsePromptTokens(int toolUsePromptTokens) {
            this.toolUsePromptTokens = toolUsePromptTokens;
            return this;
        }

        /**
         * Sets the execution time.
         *
         * @param time the execution time in seconds
         * @return this builder instance
         */
        public Builder time(double time) {
            this.time = time;
            return this;
        }

        /**
         * Builds a new ChatUsage instance with the set values.
         *
         * @return a new ChatUsage instance
         */
        public ChatUsage build() {
            return new ChatUsage(
                    inputTokens,
                    outputTokens,
                    cachedTokens,
                    cacheCreationTokens,
                    reasoningTokens,
                    toolUsePromptTokens,
                    time);
        }
    }
}
